package net.minecraft.src;

import java.util.List;
import java.util.Random;

public abstract class Entity {
	private static int nextEntityID = 0;
	public int entityId;
	public double renderDistanceWeight;
	public boolean preventEntitySpawning;
	public Entity riddenByEntity;
	public Entity ridingEntity;
	public World worldObj;
	public float prevPosX;
	public float prevPosY;
	public float prevPosZ;
	public float posX;
	public float posY;
	public float posZ;
	public float motionX;
	public float motionY;
	public float motionZ;
	public float rotationYaw;
	public float rotationPitch;
	public float prevRotationYaw;
	public float prevRotationPitch;
	public final AxisAlignedBB boundingBox;
	public boolean onGround;
	public boolean isCollidedHorizontally;
	public boolean isCollidedVertically;
	public boolean isCollided;
	public boolean velocityChanged;
	protected boolean isInWeb;
	public boolean field_9293_aM;
	public boolean isDead;
	public float yOffset;
	public float width;
	public float height;
	public float prevDistanceWalkedModified;
	public float distanceWalkedModified;
	public float fallDistance;
	private int nextStepDistance;
	public double lastTickPosX;
	public double lastTickPosY;
	public double lastTickPosZ;
	public float ySize;
	public float stepHeight;
	public boolean noClip;
	public float entityCollisionReduction;
	protected Random rand;
	public int ticksExisted;
	public int fireResistance;
	private int fire;
	protected boolean inWater;
	public int heartsLife;
	private boolean firstUpdate;
	public String skinUrl;
	public String cloakUrl;
	protected boolean isImmuneToFire;
	protected DataWatcher dataWatcher;
	private double entityRiderPitchDelta;
	private double entityRiderYawDelta;
	public boolean addedToChunk;
	public int chunkCoordX;
	public int chunkCoordY;
	public int chunkCoordZ;
	public int serverPosX;
	public int serverPosY;
	public int serverPosZ;
	public boolean ignoreFrustumCheck;
	public boolean isAirBorne;

	public Entity(World var1) {
		this.entityId = nextEntityID++;
		this.renderDistanceWeight = 1.0f;
		this.preventEntitySpawning = false;
		this.boundingBox = AxisAlignedBB.getBoundingBox(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);
		this.onGround = false;
		this.isCollided = false;
		this.velocityChanged = false;
		this.field_9293_aM = true;
		this.isDead = false;
		this.yOffset = 0.0F;
		this.width = 0.6F;
		this.height = 1.8F;
		this.prevDistanceWalkedModified = 0.0F;
		this.distanceWalkedModified = 0.0F;
		this.fallDistance = 0.0F;
		this.nextStepDistance = 1;
		this.ySize = 0.0F;
		this.stepHeight = 0.0F;
		this.noClip = false;
		this.entityCollisionReduction = 0.0F;
		this.rand = new Random();
		this.ticksExisted = 0;
		this.fireResistance = 1;
		this.fire = 0;
		this.inWater = false;
		this.heartsLife = 0;
		this.firstUpdate = true;
		this.isImmuneToFire = false;
		this.dataWatcher = new DataWatcher();
		this.addedToChunk = false;
		this.worldObj = var1;
		this.setPosition(0.0f, 0.0f, 0.0f);
		this.dataWatcher.addObject(0, Byte.valueOf((byte)0));
		this.dataWatcher.addObject(1, Short.valueOf((short)300));
		this.entityInit();
	}

	protected abstract void entityInit();

	public DataWatcher getDataWatcher() {
		return this.dataWatcher;
	}

	public boolean equals(Object var1) {
		return var1 instanceof Entity ? ((Entity)var1).entityId == this.entityId : false;
	}

	public int hashCode() {
		return this.entityId;
	}

	protected void preparePlayerToSpawn() {
		if(this.worldObj != null) {
			while(this.posY > 0.0f) {
				this.setPosition(this.posX, this.posY, this.posZ);
				if(this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox).size() == 0) {
					break;
				}

				++this.posY;
			}

			this.motionX = this.motionY = this.motionZ = (float) 0.0f;
			this.rotationPitch = 0.0F;
		}
	}

	public void setEntityDead() {
		this.isDead = true;
	}

	protected void setSize(float var1, float var2) {
		this.width = var1;
		this.height = var2;
	}

	protected void setRotation(float var1, float var2) {
		this.rotationYaw = var1 % 360.0F;
		this.rotationPitch = var2 % 360.0F;
	}

	public void setPosition(double var1, double var3, double var5) {
		this.posX = (float) var1;
		this.posY = (float) var3;
		this.posZ = (float) var5;
		float var7 = this.width / 2.0F;
		float var8 = this.height;
		this.boundingBox.setBounds(var1 - (float)var7, var3 - (float)this.yOffset + (float)this.ySize, var5 - (float)var7, var1 + (float)var7, var3 - (float)this.yOffset + (float)this.ySize + (float)var8, var5 + (float)var7);
	}

	public void setAngles(float var1, float var2) {
		float var3 = this.rotationPitch;
		float var4 = this.rotationYaw;
		this.rotationYaw = (float)((float)this.rotationYaw + (float)var1 * 0.15f);
		this.rotationPitch = (float)((float)this.rotationPitch - (float)var2 * 0.15f);
		if(this.rotationPitch < -90.0F) {
			this.rotationPitch = -90.0F;
		}

		if(this.rotationPitch > 90.0F) {
			this.rotationPitch = 90.0F;
		}

		this.prevRotationPitch += this.rotationPitch - var3;
		this.prevRotationYaw += this.rotationYaw - var4;
	}

	public void onUpdate() {
		this.onEntityUpdate();
	}

	public void onEntityUpdate() {
		Profiler.startSection("entityBaseTick");
		if(this.ridingEntity != null && this.ridingEntity.isDead) {
			this.ridingEntity = null;
		}

		++this.ticksExisted;
		this.prevDistanceWalkedModified = this.distanceWalkedModified;
		this.prevPosX = this.posX;
		this.prevPosY = this.posY;
		this.prevPosZ = this.posZ;
		this.prevRotationPitch = this.rotationPitch;
		this.prevRotationYaw = this.rotationYaw;
		int var3;
		if(this.isSprinting()) {
			int var1 = MathHelper.floor_double(this.posX);
			int var2 = MathHelper.floor_double(this.posY - 0.20000000298023224f - (float)this.yOffset);
			var3 = MathHelper.floor_double(this.posZ);
			int var4 = this.worldObj.getBlockId(var1, var2, var3);
			if(var4 > 0) {
				this.worldObj.spawnParticle("tilecrack_" + var4, this.posX + ((float)this.rand.nextFloat() - 0.5f) * (float)this.width, this.boundingBox.minY + 0.1f, this.posZ + ((float)this.rand.nextFloat() - 0.5f) * (float)this.width, -this.motionX * 4.0f, 1.5f, -this.motionZ * 4.0f);
			}
		}

		if(this.handleWaterMovement()) {
			if(!this.inWater && !this.firstUpdate) {
				float var6 = MathHelper.sqrt_double(this.motionX * this.motionX * 0.20000000298023224f + this.motionY * this.motionY + this.motionZ * this.motionZ * 0.20000000298023224f) * 0.2F;
				if(var6 > 1.0F) {
					var6 = 1.0F;
				}

				this.worldObj.playSoundAtEntity(this, "random.splash", var6, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
				float var7 = (float)MathHelper.floor_double(this.boundingBox.minY);

				float var5;
				float var8;
				for(var3 = 0; (float)var3 < 1.0F + this.width * 20.0F; ++var3) {
					var8 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
					var5 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
					this.worldObj.spawnParticle("bubble", this.posX + (float)var8, (float)(var7 + 1.0F), this.posZ + (float)var5, this.motionX, this.motionY - (float)(this.rand.nextFloat() * 0.2F), this.motionZ);
				}

				for(var3 = 0; (float)var3 < 1.0F + this.width * 20.0F; ++var3) {
					var8 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
					var5 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width;
					this.worldObj.spawnParticle("splash", this.posX + (float)var8, (float)(var7 + 1.0F), this.posZ + (float)var5, this.motionX, this.motionY, this.motionZ);
				}
			}

			this.fallDistance = 0.0F;
			this.inWater = true;
			this.fire = 0;
		} else {
			this.inWater = false;
		}

		if(this.worldObj.multiplayerWorld) {
			this.fire = 0;
		} else if(this.fire > 0) {
			if(this.isImmuneToFire) {
				this.fire -= 4;
				if(this.fire < 0) {
					this.fire = 0;
				}
			} else {
				if(this.fire % 20 == 0) {
					this.attackEntityFrom(DamageSource.onFire, 1);
				}

				--this.fire;
			}
		}

		if(this.handleLavaMovement()) {
			this.setOnFireFromLava();
			this.fallDistance *= 0.5F;
		}

		if(this.posY < -64.0f) {
			this.kill();
		}

		if(!this.worldObj.multiplayerWorld) {
			this.setFlag(0, this.fire > 0);
			this.setFlag(2, this.ridingEntity != null);
		}

		this.firstUpdate = false;
		Profiler.endSection();
	}

	protected void setOnFireFromLava() {
		if(!this.isImmuneToFire) {
			this.attackEntityFrom(DamageSource.lava, 4);
			this.setFire(15);
		}

	}

	public void setFire(int var1) {
		int var2 = var1 * 20;
		if(this.fire < var2) {
			this.fire = var2;
		}

	}

	public void extinguish() {
		this.fire = 0;
	}

	protected void kill() {
		this.setEntityDead();
	}

	public boolean isOffsetPositionInLiquid(double var1, double var3, double var5) {
		AxisAlignedBB var7 = this.boundingBox.getOffsetBoundingBox(var1, var3, var5);
		List var8 = this.worldObj.getCollidingBoundingBoxes(this, var7);
		return var8.size() > 0 ? false : !this.worldObj.getIsAnyLiquid(var7);
	}

	public void moveEntity(double var1, double var3, double var5) {
		if(this.noClip) {
			this.boundingBox.offset(var1, var3, var5);
			this.posX = (float) ((this.boundingBox.minX + this.boundingBox.maxX) / 2.0f);
			this.posY = (float) (this.boundingBox.minY + (float)this.yOffset - (float)this.ySize);
			this.posZ = (float) ((this.boundingBox.minZ + this.boundingBox.maxZ) / 2.0f);
		} else {
			Profiler.startSection("move");
			this.ySize *= 0.4F;
			double var7 = this.posX;
			double var9 = this.posZ;
			if(this.isInWeb) {
				this.isInWeb = false;
				var1 *= 0.25f;
				var3 *= 0.05000000074505806f;
				var5 *= 0.25f;
				this.motionX = (float)(float) 0.0f;
				this.motionY = (float)(float) 0.0f;
				this.motionZ = (float)(float) 0.0f;
			}

			double var11 = var1;
			double var13 = var3;
			double var15 = var5;
			AxisAlignedBB var17 = this.boundingBox.copy();
			boolean var18 = this.onGround && this.isSneaking();
			if(var18) {
				double var19;
				for(var19 = 0.05f; var1 != 0.0f && this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.getOffsetBoundingBox(var1, -1.0f, 0.0f)).size() == 0; var11 = var1) {
					if(var1 < var19 && var1 >= -var19) {
						var1 = 0.0f;
					} else if(var1 > 0.0f) {
						var1 -= var19;
					} else {
						var1 += var19;
					}
				}

				for(; var5 != 0.0f && this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.getOffsetBoundingBox(0.0f, -1.0f, var5)).size() == 0; var15 = var5) {
					if(var5 < var19 && var5 >= -var19) {
						var5 = 0.0f;
					} else if(var5 > 0.0f) {
						var5 -= var19;
					} else {
						var5 += var19;
					}
				}
			}

			List var35 = this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.addCoord(var1, var3, var5));

			for(int var20 = 0; var20 < var35.size(); ++var20) {
				var3 = ((AxisAlignedBB)var35.get(var20)).calculateYOffset(this.boundingBox, var3);
			}

			this.boundingBox.offset(0.0f, var3, 0.0f);
			if(!this.field_9293_aM && var13 != var3) {
				var5 = 0.0f;
				var3 = 0.0f;
				var1 = 0.0f;
			}

			boolean var36 = this.onGround || var13 != var3 && var13 < 0.0f;

			int var21;
			for(var21 = 0; var21 < var35.size(); ++var21) {
				var1 = ((AxisAlignedBB)var35.get(var21)).calculateXOffset(this.boundingBox, var1);
			}

			this.boundingBox.offset(var1, 0.0f, 0.0f);
			if(!this.field_9293_aM && var11 != var1) {
				var5 = 0.0f;
				var3 = 0.0f;
				var1 = 0.0f;
			}

			for(var21 = 0; var21 < var35.size(); ++var21) {
				var5 = ((AxisAlignedBB)var35.get(var21)).calculateZOffset(this.boundingBox, var5);
			}

			this.boundingBox.offset(0.0f, 0.0f, var5);
			if(!this.field_9293_aM && var15 != var5) {
				var5 = 0.0f;
				var3 = 0.0f;
				var1 = 0.0f;
			}

			double var23;
			int var28;
			double var37;
			if(this.stepHeight > 0.0F && var36 && (var18 || this.ySize < 0.05F) && (var11 != var1 || var15 != var5)) {
				var37 = var1;
				var23 = var3;
				double var25 = var5;
				var1 = var11;
				var3 = (float)this.stepHeight;
				var5 = var15;
				AxisAlignedBB var27 = this.boundingBox.copy();
				this.boundingBox.setBB(var17);
				var35 = this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.addCoord(var11, var3, var15));

				for(var28 = 0; var28 < var35.size(); ++var28) {
					var3 = ((AxisAlignedBB)var35.get(var28)).calculateYOffset(this.boundingBox, var3);
				}

				this.boundingBox.offset(0.0f, var3, 0.0f);
				if(!this.field_9293_aM && var13 != var3) {
					var5 = 0.0f;
					var3 = 0.0f;
					var1 = 0.0f;
				}

				for(var28 = 0; var28 < var35.size(); ++var28) {
					var1 = ((AxisAlignedBB)var35.get(var28)).calculateXOffset(this.boundingBox, var1);
				}

				this.boundingBox.offset(var1, 0.0f, 0.0f);
				if(!this.field_9293_aM && var11 != var1) {
					var5 = 0.0f;
					var3 = 0.0f;
					var1 = 0.0f;
				}

				for(var28 = 0; var28 < var35.size(); ++var28) {
					var5 = ((AxisAlignedBB)var35.get(var28)).calculateZOffset(this.boundingBox, var5);
				}

				this.boundingBox.offset(0.0f, 0.0f, var5);
				if(!this.field_9293_aM && var15 != var5) {
					var5 = 0.0f;
					var3 = 0.0f;
					var1 = 0.0f;
				}

				if(!this.field_9293_aM && var13 != var3) {
					var5 = 0.0f;
					var3 = 0.0f;
					var1 = 0.0f;
				} else {
					var3 = (float)(-this.stepHeight);

					for(var28 = 0; var28 < var35.size(); ++var28) {
						var3 = ((AxisAlignedBB)var35.get(var28)).calculateYOffset(this.boundingBox, var3);
					}

					this.boundingBox.offset(0.0f, var3, 0.0f);
				}

				if(var37 * var37 + var25 * var25 >= var1 * var1 + var5 * var5) {
					var1 = var37;
					var3 = var23;
					var5 = var25;
					this.boundingBox.setBB(var27);
				} else {
					double var40 = this.boundingBox.minY - (float)((int)this.boundingBox.minY);
					if(var40 > 0.0f) {
						this.ySize = (float)((float)this.ySize + var40 + 0.01f);
					}
				}
			}

			Profiler.endSection();
			Profiler.startSection("rest");
			this.posX = (float) ((this.boundingBox.minX + this.boundingBox.maxX) / 2.0f);
			this.posY = (float) (this.boundingBox.minY + (float)this.yOffset - (float)this.ySize);
			this.posZ = (float) ((this.boundingBox.minZ + this.boundingBox.maxZ) / 2.0f);
			this.isCollidedHorizontally = var11 != var1 || var15 != var5;
			this.isCollidedVertically = var13 != var3;
			this.onGround = var13 != var3 && var13 < 0.0f;
			this.isCollided = this.isCollidedHorizontally || this.isCollidedVertically;
			this.updateFallState(var3, this.onGround);
			if(var11 != var1) {
				this.motionX = (float)0.0f;
			}

			if(var13 != var3) {
				this.motionY = (float)0.0f;
			}

			if(var15 != var5) {
				this.motionZ = (float)0.0f;
			}

			var37 = this.posX - var7;
			var23 = this.posZ - var9;
			int var26;
			int var38;
			int var39;
			if(this.canTriggerWalking() && !var18 && this.ridingEntity == null) {
				this.distanceWalkedModified = (float)((float)this.distanceWalkedModified + (float)MathHelper.sqrt_double(var37 * var37 + var23 * var23) * 0.6f);
				var38 = MathHelper.floor_double(this.posX);
				var26 = MathHelper.floor_double(this.posY - 0.20000000298023224f - (float)this.yOffset);
				var39 = MathHelper.floor_double(this.posZ);
				var28 = this.worldObj.getBlockId(var38, var26, var39);
				if(var28 == 0 && this.worldObj.getBlockId(var38, var26 - 1, var39) == Block.fence.blockID) {
					var28 = this.worldObj.getBlockId(var38, var26 - 1, var39);
				}

				if(this.distanceWalkedModified > (float)this.nextStepDistance && var28 > 0) {
					this.nextStepDistance = (int)this.distanceWalkedModified + 1;
					this.func_41002_a(var38, var26, var39, var28);
					Block.blocksList[var28].onEntityWalking(this.worldObj, var38, var26, var39, this);
				}
			}

			var38 = MathHelper.floor_double(this.boundingBox.minX + 0.001f);
			var26 = MathHelper.floor_double(this.boundingBox.minY + 0.001f);
			var39 = MathHelper.floor_double(this.boundingBox.minZ + 0.001f);
			var28 = MathHelper.floor_double(this.boundingBox.maxX - 0.001f);
			int var29 = MathHelper.floor_double(this.boundingBox.maxY - 0.001f);
			int var30 = MathHelper.floor_double(this.boundingBox.maxZ - 0.001f);
			if(this.worldObj.checkChunksExist(var38, var26, var39, var28, var29, var30)) {
				for(int var31 = var38; var31 <= var28; ++var31) {
					for(int var32 = var26; var32 <= var29; ++var32) {
						for(int var33 = var39; var33 <= var30; ++var33) {
							int var34 = this.worldObj.getBlockId(var31, var32, var33);
							if(var34 > 0) {
								Block.blocksList[var34].onEntityCollidedWithBlock(this.worldObj, var31, var32, var33, this);
							}
						}
					}
				}
			}

			boolean var41 = this.isWet();
			if(this.worldObj.isBoundingBoxBurning(this.boundingBox.contract(0.001f, 0.001f, 0.001f))) {
				this.dealFireDamage(1);
				if(!var41) {
					++this.fire;
					if(this.fire == 0) {
						this.setFire(8);
					}
				}
			} else if(this.fire <= 0) {
				this.fire = -this.fireResistance;
			}

			if(var41 && this.fire > 0) {
				this.worldObj.playSoundAtEntity(this, "random.fizz", 0.7F, 1.6F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.4F);
				this.fire = -this.fireResistance;
			}

			Profiler.endSection();
		}
	}

	protected void func_41002_a(int var1, int var2, int var3, int var4) {
		StepSound var5 = Block.blocksList[var4].stepSound;
		if(this.worldObj.getBlockId(var1, var2 + 1, var3) == Block.snow.blockID) {
			var5 = Block.snow.stepSound;
			this.worldObj.playSoundAtEntity(this, var5.stepSoundDir2(), var5.getVolume() * 0.15F, var5.getPitch());
		} else if(!Block.blocksList[var4].blockMaterial.getIsLiquid()) {
			this.worldObj.playSoundAtEntity(this, var5.stepSoundDir2(), var5.getVolume() * 0.15F, var5.getPitch());
		}

	}

	protected boolean canTriggerWalking() {
		return true;
	}

	protected void updateFallState(double var1, boolean var3) {
		if(var3) {
			if(this.fallDistance > 0.0F) {
				if(this instanceof EntityLiving) {
					int var4 = MathHelper.floor_double(this.posX);
					int var5 = MathHelper.floor_double(this.posY - 0.20000000298023224f - (float)this.yOffset);
					int var6 = MathHelper.floor_double(this.posZ);
					int var7 = this.worldObj.getBlockId(var4, var5, var6);
					if(var7 == 0 && this.worldObj.getBlockId(var4, var5 - 1, var6) == Block.fence.blockID) {
						var7 = this.worldObj.getBlockId(var4, var5 - 1, var6);
					}

					if(var7 > 0) {
						Block.blocksList[var7].func_43001_a(this.worldObj, var4, var5, var6, this, this.fallDistance);
					}
				}

				this.fall(this.fallDistance);
				this.fallDistance = 0.0F;
			}
		} else if(var1 < 0.0f) {
			this.fallDistance = (float)((float)this.fallDistance - var1);
		}

	}

	public AxisAlignedBB getBoundingBox() {
		return null;
	}

	protected void dealFireDamage(int var1) {
		if(!this.isImmuneToFire) {
			this.attackEntityFrom(DamageSource.inFire, var1);
		}

	}

	public final boolean isImmuneToFire() {
		return this.isImmuneToFire;
	}

	protected void fall(float var1) {
		if(this.riddenByEntity != null) {
			this.riddenByEntity.fall(var1);
		}

	}

	public boolean isWet() {
		return this.inWater || this.worldObj.canLightningStrikeAt(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ));
	}

	public boolean isInWater() {
		return this.inWater;
	}

	public boolean handleWaterMovement() {
		return this.worldObj.handleMaterialAcceleration(this.boundingBox.expand(0.0f, -0.4000000059604645f, 0.0f).contract(0.001f, 0.001f, 0.001f), Material.water, this);
	}

	public boolean isInsideOfMaterial(Material var1) {
		double var2 = this.posY + (float)this.getEyeHeight();
		int var4 = MathHelper.floor_double(this.posX);
		int var5 = MathHelper.floor_float((float)MathHelper.floor_double(var2));
		int var6 = MathHelper.floor_double(this.posZ);
		int var7 = this.worldObj.getBlockId(var4, var5, var6);
		if(var7 != 0 && Block.blocksList[var7].blockMaterial == var1) {
			float var8 = BlockFluid.getFluidHeightPercent(this.worldObj.getBlockMetadata(var4, var5, var6)) - 0.11111111F;
			float var9 = (float)(var5 + 1) - var8;
			return var2 < (float)var9;
		} else {
			return false;
		}
	}

	public float getEyeHeight() {
		return 0.0F;
	}

	public boolean handleLavaMovement() {
		return this.worldObj.isMaterialInBB(this.boundingBox.expand(-0.10000000149011612D, -0.4000000059604645f, -0.10000000149011612D), Material.lava);
	}

	public void moveFlying(float var1, float var2, float var3) {
		float var4 = MathHelper.sqrt_float(var1 * var1 + var2 * var2);
		if(var4 >= 0.01F) {
			if(var4 < 1.0F) {
				var4 = 1.0F;
			}

			var4 = var3 / var4;
			var1 *= var4;
			var2 *= var4;
			float var5 = MathHelper.sin(this.rotationYaw * 3.1415927F / 180.0F);
			float var6 = MathHelper.cos(this.rotationYaw * 3.1415927F / 180.0F);
			this.motionX += (float)(var1 * var6 - var2 * var5);
			this.motionZ += (float)(var2 * var6 + var1 * var5);
		}
	}

	public int getEntityBrightnessForRender(float var1) {
		int var2 = MathHelper.floor_double(this.posX);
		int var3 = MathHelper.floor_double(this.posZ);
		if(this.worldObj.blockExists(var2, this.worldObj.worldHeight / 2, var3)) {
			double var4 = (this.boundingBox.maxY - this.boundingBox.minY) * 0.66f;
			int var6 = MathHelper.floor_double(this.posY - (float)this.yOffset + var4);
			return this.worldObj.getLightBrightnessForSkyBlocks(var2, var6, var3, 0);
		} else {
			return 0;
		}
	}

	public float getEntityBrightness(float var1) {
		int var2 = MathHelper.floor_double(this.posX);
		int var3 = MathHelper.floor_double(this.posZ);
		if(this.worldObj.blockExists(var2, this.worldObj.worldHeight / 2, var3)) {
			double var4 = (this.boundingBox.maxY - this.boundingBox.minY) * 0.66f;
			int var6 = MathHelper.floor_double(this.posY - (float)this.yOffset + var4);
			return this.worldObj.getLightBrightness(var2, var6, var3);
		} else {
			return 0.0F;
		}
	}

	public void setWorld(World var1) {
		this.worldObj = var1;
	}

	public void setPositionAndRotation(double var1, double var3, double var5, float var7, float var8) {
		this.prevPosX = this.posX = (float) var1;
		this.prevPosY = this.posY = (float) var3;
		this.prevPosZ = this.posZ = (float) var5;
		this.prevRotationYaw = this.rotationYaw = var7;
		this.prevRotationPitch = this.rotationPitch = var8;
		this.ySize = 0.0F;
		double var9 = (float)(this.prevRotationYaw - var7);
		if(var9 < -180.0f) {
			this.prevRotationYaw += 360.0F;
		}

		if(var9 >= 180.0f) {
			this.prevRotationYaw -= 360.0F;
		}

		this.setPosition(this.posX, this.posY, this.posZ);
		this.setRotation(var7, var8);
	}

	public void setLocationAndAngles(double var1, double var3, double var5, float var7, float var8) {
		this.lastTickPosX = this.prevPosX = this.posX = (float) var1;
		this.lastTickPosY = this.prevPosY = this.posY = (float) (var3 + (float)this.yOffset);
		this.lastTickPosZ = this.prevPosZ = this.posZ = (float) var5;
		this.rotationYaw = var7;
		this.rotationPitch = var8;
		this.setPosition(this.posX, this.posY, this.posZ);
	}

	public float getDistanceToEntity(Entity var1) {
		float var2 = (float)(this.posX - var1.posX);
		float var3 = (float)(this.posY - var1.posY);
		float var4 = (float)(this.posZ - var1.posZ);
		return MathHelper.sqrt_float(var2 * var2 + var3 * var3 + var4 * var4);
	}

	public double getDistanceSq(double var1, double var3, double var5) {
		double var7 = this.posX - var1;
		double var9 = this.posY - var3;
		double var11 = this.posZ - var5;
		return var7 * var7 + var9 * var9 + var11 * var11;
	}

	public double getDistance(double var1, double var3, double var5) {
		double var7 = this.posX - var1;
		double var9 = this.posY - var3;
		double var11 = this.posZ - var5;
		return (float)MathHelper.sqrt_double(var7 * var7 + var9 * var9 + var11 * var11);
	}

	public double getDistanceSqToEntity(Entity var1) {
		double var2 = this.posX - var1.posX;
		double var4 = this.posY - var1.posY;
		double var6 = this.posZ - var1.posZ;
		return var2 * var2 + var4 * var4 + var6 * var6;
	}

	public void onCollideWithPlayer(EntityPlayer var1) {
	}

	public void applyEntityCollision(Entity var1) {
		if(var1.riddenByEntity != this && var1.ridingEntity != this) {
			double var2 = var1.posX - this.posX;
			double var4 = var1.posZ - this.posZ;
			double var6 = MathHelper.abs_max(var2, var4);
			if(var6 >= 0.009999999776482582D) {
				var6 = (float)MathHelper.sqrt_double(var6);
				var2 /= var6;
				var4 /= var6;
				double var8 = 1.0f / var6;
				if(var8 > 1.0f) {
					var8 = 1.0f;
				}

				var2 *= var8;
				var4 *= var8;
				var2 *= 0.05000000074505806f;
				var4 *= 0.05000000074505806f;
				var2 *= (float)(1.0F - this.entityCollisionReduction);
				var4 *= (float)(1.0F - this.entityCollisionReduction);
				this.addVelocity(-var2, 0.0f, -var4);
				var1.addVelocity(var2, 0.0f, var4);
			}

		}
	}

	public void addVelocity(double var1, double var3, double var5) {
		this.motionX += var1;
		this.motionY += var3;
		this.motionZ += var5;
		this.isAirBorne = true;
	}

	protected void setBeenAttacked() {
		this.velocityChanged = true;
	}

	public boolean attackEntityFrom(DamageSource var1, int var2) {
		this.setBeenAttacked();
		return false;
	}

	public boolean canBeCollidedWith() {
		return false;
	}

	public boolean canBePushed() {
		return false;
	}

	public void addToPlayerScore(Entity var1, int var2) {
	}

	public boolean isInRangeToRenderVec3D(Vec3D var1) {
		double var2 = this.posX - var1.xCoord;
		double var4 = this.posY - var1.yCoord;
		double var6 = this.posZ - var1.zCoord;
		double var8 = var2 * var2 + var4 * var4 + var6 * var6;
		return this.isInRangeToRenderDist(var8);
	}

	public boolean isInRangeToRenderDist(double var1) {
		double var3 = this.boundingBox.getAverageEdgeLength();
		var3 *= 64.0f * this.renderDistanceWeight;
		return var1 < var3 * var3;
	}

	public String getEntityTexture() {
		return null;
	}

	public boolean addEntityID(NBTTagCompound var1) {
		String var2 = this.getEntityString();
		if(!this.isDead && var2 != null) {
			var1.setString("id", var2);
			this.writeToNBT(var1);
			return true;
		} else {
			return false;
		}
	}

	public void writeToNBT(NBTTagCompound var1) {
		var1.setTag("Pos", this.newDoubleNBTList(new double[]{this.posX, this.posY + (float)this.ySize, this.posZ}));
		var1.setTag("Motion", this.newDoubleNBTList(new double[]{this.motionX, this.motionY, this.motionZ}));
		var1.setTag("Rotation", this.newFloatNBTList(new float[]{this.rotationYaw, this.rotationPitch}));
		var1.setFloat("FallDistance", this.fallDistance);
		var1.setShort("Fire", (short)this.fire);
		var1.setShort("Air", (short)this.getAir());
		var1.setBoolean("OnGround", this.onGround);
		this.writeEntityToNBT(var1);
	}

	public void readFromNBT(NBTTagCompound var1) {
		NBTTagList var2 = var1.getTagList("Pos");
		NBTTagList var3 = var1.getTagList("Motion");
		NBTTagList var4 = var1.getTagList("Rotation");
		this.motionX = (float)(float) ((NBTTagDouble)var3.tagAt(0)).doubleValue;
		this.motionY = (float)(float) ((NBTTagDouble)var3.tagAt(1)).doubleValue;
		this.motionZ = (float)(float) ((NBTTagDouble)var3.tagAt(2)).doubleValue;
		if(Math.abs(this.motionX) > 10.0f) {
			this.motionX = (float)0.0f;
		}

		if(Math.abs(this.motionY) > 10.0f) {
			this.motionY = (float)0.0f;
		}

		if(Math.abs(this.motionZ) > 10.0f) {
			this.motionZ = (float)0.0f;
		}

		this.prevPosX = (float) (this.lastTickPosX = this.posX = (float) ((NBTTagDouble)var2.tagAt(0)).doubleValue);
		this.prevPosY = (float) (this.lastTickPosY = this.posY = (float) ((NBTTagDouble)var2.tagAt(1)).doubleValue);
		this.prevPosZ = (float) (this.lastTickPosZ = this.posZ = (float) ((NBTTagDouble)var2.tagAt(2)).doubleValue);
		this.prevRotationYaw = this.rotationYaw = ((NBTTagFloat)var4.tagAt(0)).floatValue;
		this.prevRotationPitch = this.rotationPitch = ((NBTTagFloat)var4.tagAt(1)).floatValue;
		this.fallDistance = var1.getFloat("FallDistance");
		this.fire = var1.getShort("Fire");
		this.setAir(var1.getShort("Air"));
		this.onGround = var1.getBoolean("OnGround");
		this.setPosition(this.posX, this.posY, this.posZ);
		this.setRotation(this.rotationYaw, this.rotationPitch);
		this.readEntityFromNBT(var1);
	}

	protected final String getEntityString() {
		return EntityList.getEntityString(this);
	}

	protected abstract void readEntityFromNBT(NBTTagCompound var1);

	protected abstract void writeEntityToNBT(NBTTagCompound var1);

	protected NBTTagList newDoubleNBTList(double... var1) {
		NBTTagList var2 = new NBTTagList();
		double[] var3 = var1;
		int var4 = var1.length;

		for(int var5 = 0; var5 < var4; ++var5) {
			double var6 = var3[var5];
			var2.setTag(new NBTTagDouble((String)null, var6));
		}

		return var2;
	}

	protected NBTTagList newFloatNBTList(float... var1) {
		NBTTagList var2 = new NBTTagList();
		float[] var3 = var1;
		int var4 = var1.length;

		for(int var5 = 0; var5 < var4; ++var5) {
			float var6 = var3[var5];
			var2.setTag(new NBTTagFloat((String)null, var6));
		}

		return var2;
	}

	public float getShadowSize() {
		return this.height / 2.0F;
	}

	public EntityItem dropItem(int var1, int var2) {
		return this.dropItemWithOffset(var1, var2, 0.0F);
	}

	public EntityItem dropItemWithOffset(int var1, int var2, float var3) {
		return this.entityDropItem(new ItemStack(var1, var2, 0), var3);
	}

	public EntityItem entityDropItem(ItemStack var1, float var2) {
		EntityItem var3 = new EntityItem(this.worldObj, this.posX, this.posY + (float)var2, this.posZ, var1);
		var3.delayBeforeCanPickup = 10;
		this.worldObj.spawnEntityInWorld(var3);
		return var3;
	}

	public boolean isEntityAlive() {
		return !this.isDead;
	}

	public boolean isEntityInsideOpaqueBlock() {
		for(int var1 = 0; var1 < 8; ++var1) {
			float var2 = ((float)((var1 >> 0) % 2) - 0.5F) * this.width * 0.8F;
			float var3 = ((float)((var1 >> 1) % 2) - 0.5F) * 0.1F;
			float var4 = ((float)((var1 >> 2) % 2) - 0.5F) * this.width * 0.8F;
			int var5 = MathHelper.floor_double(this.posX + (float)var2);
			int var6 = MathHelper.floor_double(this.posY + (float)this.getEyeHeight() + (float)var3);
			int var7 = MathHelper.floor_double(this.posZ + (float)var4);
			if(this.worldObj.isBlockNormalCube(var5, var6, var7)) {
				return true;
			}
		}

		return false;
	}

	public boolean interact(EntityPlayer var1) {
		return false;
	}

	public AxisAlignedBB getCollisionBox(Entity var1) {
		return null;
	}

	public void updateRidden() {
		if(this.ridingEntity.isDead) {
			this.ridingEntity = null;
		} else {
			this.motionX = (float)0.0f;
			this.motionY = (float)0.0f;
			this.motionZ = (float)0.0f;
			this.onUpdate();
			if(this.ridingEntity != null) {
				this.ridingEntity.updateRiderPosition();
				this.entityRiderYawDelta += (float)(this.ridingEntity.rotationYaw - this.ridingEntity.prevRotationYaw);

				for(this.entityRiderPitchDelta += (float)(this.ridingEntity.rotationPitch - this.ridingEntity.prevRotationPitch); this.entityRiderYawDelta >= 180.0f; this.entityRiderYawDelta -= 360.0f) {
					;
				}

				while(this.entityRiderYawDelta < -180.0f) {
					this.entityRiderYawDelta += 360.0f;
				}

				while(this.entityRiderPitchDelta >= 180.0f) {
					this.entityRiderPitchDelta -= 360.0f;
				}

				while(this.entityRiderPitchDelta < -180.0f) {
					this.entityRiderPitchDelta += 360.0f;
				}

				double var1 = this.entityRiderYawDelta * 0.5f;
				double var3 = this.entityRiderPitchDelta * 0.5f;
				float var5 = 10.0F;
				if(var1 > (float)var5) {
					var1 = (float)var5;
				}

				if(var1 < (float)(-var5)) {
					var1 = (float)(-var5);
				}

				if(var3 > (float)var5) {
					var3 = (float)var5;
				}

				if(var3 < (float)(-var5)) {
					var3 = (float)(-var5);
				}

				this.entityRiderYawDelta -= var1;
				this.entityRiderPitchDelta -= var3;
				this.rotationYaw = (float)((float)this.rotationYaw + var1);
				this.rotationPitch = (float)((float)this.rotationPitch + var3);
			}
		}
	}

	public void updateRiderPosition() {
		this.riddenByEntity.setPosition(this.posX, this.posY + this.getMountedYOffset() + this.riddenByEntity.getYOffset(), this.posZ);
	}

	public double getYOffset() {
		return (float)this.yOffset;
	}

	public double getMountedYOffset() {
		return (float)this.height * 0.75f;
	}

	public void mountEntity(Entity var1) {
		this.entityRiderPitchDelta = 0.0f;
		this.entityRiderYawDelta = 0.0f;
		if(var1 == null) {
			if(this.ridingEntity != null) {
				this.setLocationAndAngles(this.ridingEntity.posX, this.ridingEntity.boundingBox.minY + (float)this.ridingEntity.height, this.ridingEntity.posZ, this.rotationYaw, this.rotationPitch);
				this.ridingEntity.riddenByEntity = null;
			}

			this.ridingEntity = null;
		} else if(this.ridingEntity == var1) {
			this.ridingEntity.riddenByEntity = null;
			this.ridingEntity = null;
			this.setLocationAndAngles(var1.posX, var1.boundingBox.minY + (float)var1.height, var1.posZ, this.rotationYaw, this.rotationPitch);
		} else {
			if(this.ridingEntity != null) {
				this.ridingEntity.riddenByEntity = null;
			}

			if(var1.riddenByEntity != null) {
				var1.riddenByEntity.ridingEntity = null;
			}

			this.ridingEntity = var1;
			var1.riddenByEntity = this;
		}
	}

	public void setPositionAndRotation2(double var1, double var3, double var5, float var7, float var8, int var9) {
		this.setPosition(var1, var3, var5);
		this.setRotation(var7, var8);
		List var10 = this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox.contract(0.03125f, 0.0f, 0.03125f));
		if(var10.size() > 0) {
			double var11 = 0.0f;

			for(int var13 = 0; var13 < var10.size(); ++var13) {
				AxisAlignedBB var14 = (AxisAlignedBB)var10.get(var13);
				if(var14.maxY > var11) {
					var11 = var14.maxY;
				}
			}

			var3 += var11 - this.boundingBox.minY;
			this.setPosition(var1, var3, var5);
		}

	}

	public float getCollisionBorderSize() {
		return 0.1F;
	}

	public Vec3D getLookVec() {
		return null;
	}

	public void setInPortal() {
	}

	public void setVelocity(double var1, double var3, double var5) {
		this.motionX = (float)(float) var1;
		this.motionY = (float)(float) var3;
		this.motionZ = (float)(float) var5;
	}

	public void handleHealthUpdate(byte var1) {
	}

	public void performHurtAnimation() {
	}

	public void updateCloak() {
	}

	public void outfitWithItem(int var1, int var2, int var3) {
	}

	public boolean isBurning() {
		return this.fire > 0 || this.getFlag(0);
	}

	public boolean isRiding() {
		return this.ridingEntity != null || this.getFlag(2);
	}

	public boolean isSneaking() {
		return this.getFlag(1);
	}

	public boolean isSprinting() {
		return this.getFlag(3);
	}

	public void setSprinting(boolean var1) {
		this.setFlag(3, var1);
	}

	public boolean isEating() {
		return this.getFlag(4);
	}

	public void setEating(boolean var1) {
		this.setFlag(4, var1);
	}

	protected boolean getFlag(int var1) {
		return (this.dataWatcher.getWatchableObjectByte(0) & 1 << var1) != 0;
	}

	protected void setFlag(int var1, boolean var2) {
		byte var3 = this.dataWatcher.getWatchableObjectByte(0);
		if(var2) {
			this.dataWatcher.updateObject(0, Byte.valueOf((byte)(var3 | 1 << var1)));
		} else {
			this.dataWatcher.updateObject(0, Byte.valueOf((byte)(var3 & ~(1 << var1))));
		}

	}

	public int getAir() {
		return this.dataWatcher.getWatchableObjectShort(1);
	}

	public void setAir(int var1) {
		this.dataWatcher.updateObject(1, Short.valueOf((short)var1));
	}

	public void onStruckByLightning(EntityLightningBolt var1) {
		this.dealFireDamage(5);
		++this.fire;
		if(this.fire == 0) {
			this.setFire(8);
		}

	}

	public void onKillEntity(EntityLiving var1) {
	}

	protected boolean pushOutOfBlocks(double var1, double var3, double var5) {
		int var7 = MathHelper.floor_double(var1);
		int var8 = MathHelper.floor_double(var3);
		int var9 = MathHelper.floor_double(var5);
		double var10 = var1 - (float)var7;
		double var12 = var3 - (float)var8;
		double var14 = var5 - (float)var9;
		if(this.worldObj.isBlockNormalCube(var7, var8, var9)) {
			boolean var16 = !this.worldObj.isBlockNormalCube(var7 - 1, var8, var9);
			boolean var17 = !this.worldObj.isBlockNormalCube(var7 + 1, var8, var9);
			boolean var18 = !this.worldObj.isBlockNormalCube(var7, var8 - 1, var9);
			boolean var19 = !this.worldObj.isBlockNormalCube(var7, var8 + 1, var9);
			boolean var20 = !this.worldObj.isBlockNormalCube(var7, var8, var9 - 1);
			boolean var21 = !this.worldObj.isBlockNormalCube(var7, var8, var9 + 1);
			byte var22 = -1;
			double var23 = 9999.0f;
			if(var16 && var10 < var23) {
				var23 = var10;
				var22 = 0;
			}

			if(var17 && 1.0f - var10 < var23) {
				var23 = 1.0f - var10;
				var22 = 1;
			}

			if(var18 && var12 < var23) {
				var23 = var12;
				var22 = 2;
			}

			if(var19 && 1.0f - var12 < var23) {
				var23 = 1.0f - var12;
				var22 = 3;
			}

			if(var20 && var14 < var23) {
				var23 = var14;
				var22 = 4;
			}

			if(var21 && 1.0f - var14 < var23) {
				var23 = 1.0f - var14;
				var22 = 5;
			}

			float var25 = this.rand.nextFloat() * 0.2F + 0.1F;
			if(var22 == 0) {
				this.motionX = (float)(float)(-var25);
			}

			if(var22 == 1) {
				this.motionX = (float)(float)var25;
			}

			if(var22 == 2) {
				this.motionY = (float)(float)(-var25);
			}

			if(var22 == 3) {
				this.motionY = (float)(float)var25;
			}

			if(var22 == 4) {
				this.motionZ = (float)(float)(-var25);
			}

			if(var22 == 5) {
				this.motionZ = (float)(float)var25;
			}

			return true;
		} else {
			return false;
		}
	}

	public void setInWeb() {
		this.isInWeb = true;
		this.fallDistance = 0.0F;
	}

	public Entity[] getParts() {
		return null;
	}

	public boolean isEntityEqual(Entity var1) {
		return this == var1;
	}
}

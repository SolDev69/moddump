package net.minecraft.src;

import java.util.Iterator;
import java.util.List;

public class EntityWolf extends EntityAnimal {
	private boolean looksWithInterest = false;
	private float field_25048_b;
	private float field_25054_c;
	private boolean isShaking;
	private boolean field_25052_g;
	private float timeWolfIsShaking;
	private float prevTimeWolfIsShaking;

	public EntityWolf(World var1) {
		super(var1);
		this.texture = "/mob/wolf.png";
		this.setSize(0.8F, 0.8F);
		this.moveSpeed = 1.1F;
	}

	public int getMaxHealth() {
		return this.isTamed() ? 20 : 8;
	}

	protected void entityInit() {
		super.entityInit();
		this.dataWatcher.addObject(16, Byte.valueOf((byte)0));
		this.dataWatcher.addObject(17, "");
		this.dataWatcher.addObject(18, new Integer(this.getEntityHealth()));
	}

	protected boolean canTriggerWalking() {
		return false;
	}

	public String getEntityTexture() {
		return this.isTamed() ? "/mob/wolf_tame.png" : (this.isAngry() ? "/mob/wolf_angry.png" : super.getEntityTexture());
	}

	public void writeEntityToNBT(NBTTagCompound var1) {
		super.writeEntityToNBT(var1);
		var1.setBoolean("Angry", this.isAngry());
		var1.setBoolean("Sitting", this.isSitting());
		if(this.getOwner() == null) {
			var1.setString("Owner", "");
		} else {
			var1.setString("Owner", this.getOwner());
		}

	}

	public void readEntityFromNBT(NBTTagCompound var1) {
		super.readEntityFromNBT(var1);
		this.setAngry(var1.getBoolean("Angry"));
		this.setIsSitting(var1.getBoolean("Sitting"));
		String var2 = var1.getString("Owner");
		if(var2.length() > 0) {
			this.setOwner(var2);
			this.setIsTamed(true);
		}

	}

	protected boolean canDespawn() {
		return this.isAngry();
	}

	protected String getLivingSound() {
		return this.isAngry() ? "mob.wolf.growl" : (this.rand.nextInt(3) == 0 ? (this.isTamed() && this.dataWatcher.getWatchableObjectInt(18) < 10 ? "mob.wolf.whine" : "mob.wolf.panting") : "mob.wolf.bark");
	}

	protected String getHurtSound() {
		return "mob.wolf.hurt";
	}

	protected String getDeathSound() {
		return "mob.wolf.death";
	}

	protected float getSoundVolume() {
		return 0.4F;
	}

	protected int getDropItemId() {
		return -1;
	}

	protected void updateEntityActionState() {
		super.updateEntityActionState();
		if(!this.hasAttacked && !this.hasPath() && this.isTamed() && this.ridingEntity == null) {
			EntityPlayer var3 = this.worldObj.getPlayerEntityByName(this.getOwner());
			if(var3 != null) {
				float var2 = var3.getDistanceToEntity(this);
				if(var2 > 5.0F) {
					this.getPathOrWalkableBlock(var3, var2);
				}
			} else if(!this.isInWater()) {
				this.setIsSitting(true);
			}
		} else if(this.entityToAttack == null && !this.hasPath() && !this.isTamed() && this.worldObj.rand.nextInt(100) == 0) {
			List var1 = this.worldObj.getEntitiesWithinAABB(EntitySheep.class, AxisAlignedBB.getBoundingBoxFromPool(this.posX, this.posY, this.posZ, this.posX + 1.0D, this.posY + 1.0D, this.posZ + 1.0D).expand(16.0D, 4.0D, 16.0D));
			if(!var1.isEmpty()) {
				this.setEntityToAttack((Entity)var1.get(this.worldObj.rand.nextInt(var1.size())));
			}
		}

		if(this.isInWater()) {
			this.setIsSitting(false);
		}

		if(!this.worldObj.multiplayerWorld) {
			this.dataWatcher.updateObject(18, Integer.valueOf(this.getEntityHealth()));
		}

	}

	public void onLivingUpdate() {
		super.onLivingUpdate();
		this.looksWithInterest = false;
		if(this.hasCurrentTarget() && !this.hasPath() && !this.isAngry()) {
			Entity var1 = this.getCurrentTarget();
			if(var1 instanceof EntityPlayer) {
				EntityPlayer var2 = (EntityPlayer)var1;
				ItemStack var3 = var2.inventory.getCurrentItem();
				if(var3 != null) {
					if(!this.isTamed() && var3.itemID == Item.bone.shiftedIndex) {
						this.looksWithInterest = true;
					} else if(this.isTamed() && Item.itemsList[var3.itemID] instanceof ItemFood) {
						this.looksWithInterest = ((ItemFood)Item.itemsList[var3.itemID]).getIsWolfsFavoriteMeat();
					}
				}
			}
		}

		if(!this.worldObj.multiplayerWorld && this.isShaking && !this.field_25052_g && !this.hasPath() && this.onGround) {
			this.field_25052_g = true;
			this.timeWolfIsShaking = 0.0F;
			this.prevTimeWolfIsShaking = 0.0F;
			this.worldObj.setEntityState(this, (byte)8);
		}

	}

	public void onUpdate() {
		super.onUpdate();
		this.field_25054_c = this.field_25048_b;
		if(this.looksWithInterest) {
			this.field_25048_b += (1.0F - this.field_25048_b) * 0.4F;
		} else {
			this.field_25048_b += (0.0F - this.field_25048_b) * 0.4F;
		}

		if(this.looksWithInterest) {
			this.numTicksToChaseTarget = 10;
		}

		if(this.isWet()) {
			this.isShaking = true;
			this.field_25052_g = false;
			this.timeWolfIsShaking = 0.0F;
			this.prevTimeWolfIsShaking = 0.0F;
		} else if((this.isShaking || this.field_25052_g) && this.field_25052_g) {
			if(this.timeWolfIsShaking == 0.0F) {
				this.worldObj.playSoundAtEntity(this, "mob.wolf.shake", this.getSoundVolume(), (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
			}

			this.prevTimeWolfIsShaking = this.timeWolfIsShaking;
			this.timeWolfIsShaking += 0.05F;
			if(this.prevTimeWolfIsShaking >= 2.0F) {
				this.isShaking = false;
				this.field_25052_g = false;
				this.prevTimeWolfIsShaking = 0.0F;
				this.timeWolfIsShaking = 0.0F;
			}

			if(this.timeWolfIsShaking > 0.4F) {
				float var1 = (float)this.boundingBox.minY;
				int var2 = (int)(MathHelper.sin((this.timeWolfIsShaking - 0.4F) * 3.1415927F) * 7.0F);

				for(int var3 = 0; var3 < var2; ++var3) {
					float var4 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width * 0.5F;
					float var5 = (this.rand.nextFloat() * 2.0F - 1.0F) * this.width * 0.5F;
					this.worldObj.spawnParticle("splash", this.posX + (float)var4, (float)(var1 + 0.8F), this.posZ + (float)var5, this.motionX, this.motionY, this.motionZ);
				}
			}
		}

	}

	public boolean getWolfShaking() {
		return this.isShaking;
	}

	public float getShadingWhileShaking(float var1) {
		return 0.75F + (this.prevTimeWolfIsShaking + (this.timeWolfIsShaking - this.prevTimeWolfIsShaking) * var1) / 2.0F * 0.25F;
	}

	public float getShakeAngle(float var1, float var2) {
		float var3 = (this.prevTimeWolfIsShaking + (this.timeWolfIsShaking - this.prevTimeWolfIsShaking) * var1 + var2) / 1.8F;
		if(var3 < 0.0F) {
			var3 = 0.0F;
		} else if(var3 > 1.0F) {
			var3 = 1.0F;
		}

		return MathHelper.sin(var3 * 3.1415927F) * MathHelper.sin(var3 * 3.1415927F * 11.0F) * 0.15F * 3.1415927F;
	}

	public float getInterestedAngle(float var1) {
		return (this.field_25054_c + (this.field_25048_b - this.field_25054_c) * var1) * 0.15F * 3.1415927F;
	}

	public float getEyeHeight() {
		return this.height * 0.8F;
	}

	public int getVerticalFaceSpeed() {
		return this.isSitting() ? 20 : super.getVerticalFaceSpeed();
	}

	private void getPathOrWalkableBlock(Entity var1, float var2) {
		PathEntity var3 = this.worldObj.getPathToEntity(this, var1, 16.0F);
		if(var3 == null && var2 > 12.0F) {
			int var4 = MathHelper.floor_double(var1.posX) - 2;
			int var5 = MathHelper.floor_double(var1.posZ) - 2;
			int var6 = MathHelper.floor_double(var1.boundingBox.minY);

			for(int var7 = 0; var7 <= 4; ++var7) {
				for(int var8 = 0; var8 <= 4; ++var8) {
					if((var7 < 1 || var8 < 1 || var7 > 3 || var8 > 3) && this.worldObj.isBlockNormalCube(var4 + var7, var6 - 1, var5 + var8) && !this.worldObj.isBlockNormalCube(var4 + var7, var6, var5 + var8) && !this.worldObj.isBlockNormalCube(var4 + var7, var6 + 1, var5 + var8)) {
						this.setLocationAndAngles((float)((float)(var4 + var7) + 0.5F), (float)var6, (float)((float)(var5 + var8) + 0.5F), this.rotationYaw, this.rotationPitch);
						return;
					}
				}
			}
		} else {
			this.setPathToEntity(var3);
		}

	}

	protected boolean isMovementCeased() {
		return this.isSitting() || this.field_25052_g;
	}

	public boolean attackEntityFrom(DamageSource var1, int var2) {
		Entity var3 = var1.getEntity();
		this.setIsSitting(false);
		if(var3 != null && !(var3 instanceof EntityPlayer) && !(var3 instanceof EntityArrow)) {
			var2 = (var2 + 1) / 2;
		}

		if(!super.attackEntityFrom(var1, var2)) {
			return false;
		} else {
			if(!this.isTamed() && !this.isAngry()) {
				if(var3 instanceof EntityPlayer) {
					this.setAngry(true);
					this.entityToAttack = var3;
				}

				if(var3 instanceof EntityArrow && ((EntityArrow)var3).shootingEntity != null) {
					var3 = ((EntityArrow)var3).shootingEntity;
				}

				if(var3 instanceof EntityLiving) {
					List var4 = this.worldObj.getEntitiesWithinAABB(EntityWolf.class, AxisAlignedBB.getBoundingBoxFromPool(this.posX, this.posY, this.posZ, this.posX + 1.0D, this.posY + 1.0D, this.posZ + 1.0D).expand(16.0D, 4.0D, 16.0D));
					Iterator var5 = var4.iterator();

					while(var5.hasNext()) {
						Entity var6 = (Entity)var5.next();
						EntityWolf var7 = (EntityWolf)var6;
						if(!var7.isTamed() && var7.entityToAttack == null) {
							var7.entityToAttack = var3;
							if(var3 instanceof EntityPlayer) {
								var7.setAngry(true);
							}
						}
					}
				}
			} else if(var3 != this && var3 != null) {
				if(this.isTamed() && var3 instanceof EntityPlayer && ((EntityPlayer)var3).username.equalsIgnoreCase(this.getOwner())) {
					return true;
				}

				this.entityToAttack = var3;
			}

			return true;
		}
	}

	protected Entity findPlayerToAttack() {
		return this.isAngry() ? this.worldObj.getClosestPlayerToEntity(this, 16.0D) : null;
	}

	protected void attackEntity(Entity var1, float var2) {
		if(var2 > 2.0F && var2 < 6.0F && this.rand.nextInt(10) == 0) {
			if(this.onGround) {
				double var8 = var1.posX - this.posX;
				double var5 = var1.posZ - this.posZ;
				float var7 = MathHelper.sqrt_double(var8 * var8 + var5 * var5);
				this.motionX = (float) ((float)var8 / (float)var7 * 0.5D * 0.800000011920929D + this.motionX * 0.20000000298023224D);
				this.motionZ = (float) ((float)var5 / (float)var7 * 0.5D * 0.800000011920929D + this.motionZ * 0.20000000298023224D);
				this.motionY = (float)0.4000000059604645D;
			}
		} else if((float)var2 < 1.5D && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY) {
			this.attackTime = 20;
			byte var3 = 2;
			if(this.isTamed()) {
				var3 = 4;
			}

			var1.attackEntityFrom(DamageSource.causeMobDamage(this), var3);
		}

	}

	public boolean interact(EntityPlayer var1) {
		ItemStack var2 = var1.inventory.getCurrentItem();
		if(!this.isTamed()) {
			if(var2 != null && var2.itemID == Item.bone.shiftedIndex && !this.isAngry()) {
				--var2.stackSize;
				if(var2.stackSize <= 0) {
					var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
				}

				if(!this.worldObj.multiplayerWorld) {
					if(this.rand.nextInt(3) == 0) {
						this.setIsTamed(true);
						this.setPathToEntity((PathEntity)null);
						this.setIsSitting(true);
						this.setEntityHealth(20);
						this.setOwner(var1.username);
						this.showHeartsOrSmokeFX(true);
						this.worldObj.setEntityState(this, (byte)7);
					} else {
						this.showHeartsOrSmokeFX(false);
						this.worldObj.setEntityState(this, (byte)6);
					}
				}

				return true;
			}
		} else {
			if(var2 != null && Item.itemsList[var2.itemID] instanceof ItemFood) {
				ItemFood var3 = (ItemFood)Item.itemsList[var2.itemID];
				if(var3.getIsWolfsFavoriteMeat() && this.dataWatcher.getWatchableObjectInt(18) < 20) {
					--var2.stackSize;
					this.heal(var3.getHealAmount());
					if(var2.stackSize <= 0) {
						var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
					}

					return true;
				}
			}

			if(var1.username.equalsIgnoreCase(this.getOwner())) {
				if(!this.worldObj.multiplayerWorld) {
					this.setIsSitting(!this.isSitting());
					this.isJumping = false;
					this.setPathToEntity((PathEntity)null);
				}

				return true;
			}
		}

		return super.interact(var1);
	}

	void showHeartsOrSmokeFX(boolean var1) {
		String var2 = "heart";
		if(!var1) {
			var2 = "smoke";
		}

		for(int var3 = 0; var3 < 7; ++var3) {
			double var4 = this.rand.nextGaussian() * 0.02D;
			double var6 = this.rand.nextGaussian() * 0.02D;
			double var8 = this.rand.nextGaussian() * 0.02D;
			this.worldObj.spawnParticle(var2, this.posX + (float)(this.rand.nextFloat() * this.width * 2.0F) - (float)this.width, this.posY + 0.5D + (float)(this.rand.nextFloat() * this.height), this.posZ + (float)(this.rand.nextFloat() * this.width * 2.0F) - (float)this.width, var4, var6, var8);
		}

	}

	public void handleHealthUpdate(byte var1) {
		if(var1 == 7) {
			this.showHeartsOrSmokeFX(true);
		} else if(var1 == 6) {
			this.showHeartsOrSmokeFX(false);
		} else if(var1 == 8) {
			this.field_25052_g = true;
			this.timeWolfIsShaking = 0.0F;
			this.prevTimeWolfIsShaking = 0.0F;
		} else {
			super.handleHealthUpdate(var1);
		}

	}

	public float setTailRotation() {
		return this.isAngry() ? 1.5393804F : (this.isTamed() ? (0.55F - (float)(20 - this.dataWatcher.getWatchableObjectInt(18)) * 0.02F) * 3.1415927F : 0.62831855F);
	}

	public int getMaxSpawnedInChunk() {
		return 8;
	}

	public String getOwner() {
		return this.dataWatcher.getWatchableObjectString(17);
	}

	public void setOwner(String var1) {
		this.dataWatcher.updateObject(17, var1);
	}

	public boolean isSitting() {
		return (this.dataWatcher.getWatchableObjectByte(16) & 1) != 0;
	}

	public void setIsSitting(boolean var1) {
		byte var2 = this.dataWatcher.getWatchableObjectByte(16);
		if(var1) {
			this.dataWatcher.updateObject(16, Byte.valueOf((byte)(var2 | 1)));
		} else {
			this.dataWatcher.updateObject(16, Byte.valueOf((byte)(var2 & -2)));
		}

	}

	public boolean isAngry() {
		return (this.dataWatcher.getWatchableObjectByte(16) & 2) != 0;
	}

	public void setAngry(boolean var1) {
		byte var2 = this.dataWatcher.getWatchableObjectByte(16);
		if(var1) {
			this.dataWatcher.updateObject(16, Byte.valueOf((byte)(var2 | 2)));
		} else {
			this.dataWatcher.updateObject(16, Byte.valueOf((byte)(var2 & -3)));
		}

	}

	public boolean isTamed() {
		return (this.dataWatcher.getWatchableObjectByte(16) & 4) != 0;
	}

	public void setIsTamed(boolean var1) {
		byte var2 = this.dataWatcher.getWatchableObjectByte(16);
		if(var1) {
			this.dataWatcher.updateObject(16, Byte.valueOf((byte)(var2 | 4)));
		} else {
			this.dataWatcher.updateObject(16, Byte.valueOf((byte)(var2 & -5)));
		}

	}

	protected EntityAnimal spawnBabyAnimal(EntityAnimal var1) {
		return new EntityWolf(this.worldObj);
	}
}

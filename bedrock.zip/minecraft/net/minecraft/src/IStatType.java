package net.minecraft.src;

public interface IStatType {
	String format(int var1);
}

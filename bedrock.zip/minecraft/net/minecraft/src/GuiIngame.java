package net.minecraft.src;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

public class GuiIngame extends Gui {
	private static RenderItem itemRenderer = new RenderItem();
	private List chatMessageList = new ArrayList();
	private Random rand = new Random();
	private Minecraft mc;
	public String field_933_a = null;
	private int updateCounter = 0;
	private String recordPlaying = "";
	private int recordPlayingUpFor = 0;
	private boolean recordIsPlaying = false;
	public float damageGuiPartialTime;
	float prevVignetteBrightness = 1.0F;

	public GuiIngame(Minecraft var1) {
		this.mc = var1;
	}

	public void renderGameOverlay(float var1, boolean var2, int var3, int var4) {
		ScaledResolution var5 = new ScaledResolution(this.mc.gameSettings, this.mc.displayWidth, this.mc.displayHeight);
		int var6 = var5.getScaledWidth();
		int var7 = var5.getScaledHeight();
		FontRenderer var8 = this.mc.fontRenderer;
		this.mc.entityRenderer.setupOverlayRendering();
		GL11.glEnable(GL11.GL_BLEND);
		if(Minecraft.isFancyGraphicsEnabled()) {
			this.renderVignette(this.mc.thePlayer.getEntityBrightness(var1), var6, var7);
		} else {
			GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		}

		ItemStack var9 = this.mc.thePlayer.inventory.armorItemInSlot(3);
		if(this.mc.gameSettings.thirdPersonView == 0 && var9 != null && var9.itemID == Block.pumpkin.blockID) {
			this.renderPumpkinBlur(var6, var7);
		}

		float var10;
		if(!this.mc.thePlayer.isPotionActive(Potion.confusion)) {
			var10 = this.mc.thePlayer.prevTimeInPortal + (this.mc.thePlayer.timeInPortal - this.mc.thePlayer.prevTimeInPortal) * var1;
			if(var10 > 0.0F) {
				this.renderPortalOverlay(var10, var6, var7);
			}
		}

		boolean var11;
		int var12;
		int var13;
		int var16;
		int var17;
		int var18;
		int var20;
		int var22;
		int var50;
		if(!this.mc.playerController.func_35643_e()) {
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.mc.renderEngine.getTexture("/gui/gui.png"));
			InventoryPlayer var31 = this.mc.thePlayer.inventory;
			this.zLevel = -90.0F;
			this.drawTexturedModalRect(var6 / 2 - 91, var7 - 22, 0, 0, 182, 22);
			this.drawTexturedModalRect(var6 / 2 - 91 - 1 + var31.currentItem * 20, var7 - 22 - 1, 0, 22, 24, 22);
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.mc.renderEngine.getTexture("/gui/icons.png"));
			GL11.glEnable(GL11.GL_BLEND);
			GL11.glBlendFunc(GL11.GL_ONE_MINUS_DST_COLOR, GL11.GL_ONE_MINUS_SRC_COLOR);
			this.drawTexturedModalRect(var6 / 2 - 7, var7 / 2 - 7, 0, 0, 16, 16);
			GL11.glDisable(GL11.GL_BLEND);
			var11 = this.mc.thePlayer.heartsLife / 3 % 2 == 1;
			if(this.mc.thePlayer.heartsLife < 10) {
				var11 = false;
			}

			var12 = this.mc.thePlayer.getEntityHealth();
			var13 = this.mc.thePlayer.prevHealth;
			this.rand.setSeed((long)(this.updateCounter * 312871));
			boolean var14 = false;
			FoodStats var15 = this.mc.thePlayer.getFoodStats();
			var16 = var15.getFoodLevel();
			var17 = var15.getPrevFoodLevel();
			this.renderBossHealth();
			int var19;
			if(this.mc.playerController.shouldDrawHUD()) {
				var18 = var6 / 2 - 91;
				var19 = var6 / 2 + 91;
				var20 = this.mc.thePlayer.xpBarCap();
				int var23;
				if(var20 > 0) {
					short var21 = 182;
					var22 = (int)(this.mc.thePlayer.currentXP * (float)(var21 + 1));
					var23 = var7 - 32 + 3;
					this.drawTexturedModalRect(var18, var23, 0, 64, var21, 5);
					if(var22 > 0) {
						this.drawTexturedModalRect(var18, var23, 0, 69, var22, 5);
					}
				}

				var50 = var7 - 39;
				var22 = var50 - 10;
				var23 = this.mc.thePlayer.getTotalArmorValue();
				int var24 = -1;
				if(this.mc.thePlayer.isPotionActive(Potion.regeneration)) {
					var24 = this.updateCounter % 25;
				}

				int var25;
				int var26;
				int var29;
				for(var25 = 0; var25 < 10; ++var25) {
					if(var23 > 0) {
						var26 = var18 + var25 * 8;
						if(var25 * 2 + 1 < var23) {
							this.drawTexturedModalRect(var26, var22, 34, 9, 9, 9);
						}

						if(var25 * 2 + 1 == var23) {
							this.drawTexturedModalRect(var26, var22, 25, 9, 9, 9);
						}

						if(var25 * 2 + 1 > var23) {
							this.drawTexturedModalRect(var26, var22, 16, 9, 9, 9);
						}
					}

					var26 = 16;
					if(this.mc.thePlayer.isPotionActive(Potion.poison)) {
						var26 += 36;
					}

					byte var27 = 0;
					if(var11) {
						var27 = 1;
					}

					int var28 = var18 + var25 * 8;
					var29 = var50;
					if(var12 <= 4) {
						var29 = var50 + this.rand.nextInt(2);
					}

					if(var25 == var24) {
						var29 -= 2;
					}

					byte var30 = 0;
					if(this.mc.theWorld.getWorldInfo().isHardcoreModeEnabled()) {
						var30 = 5;
					}

					this.drawTexturedModalRect(var28, var29, 16 + var27 * 9, 9 * var30, 9, 9);
					if(var11) {
						if(var25 * 2 + 1 < var13) {
							this.drawTexturedModalRect(var28, var29, var26 + 54, 9 * var30, 9, 9);
						}

						if(var25 * 2 + 1 == var13) {
							this.drawTexturedModalRect(var28, var29, var26 + 63, 9 * var30, 9, 9);
						}
					}

					if(var25 * 2 + 1 < var12) {
						this.drawTexturedModalRect(var28, var29, var26 + 36, 9 * var30, 9, 9);
					}

					if(var25 * 2 + 1 == var12) {
						this.drawTexturedModalRect(var28, var29, var26 + 45, 9 * var30, 9, 9);
					}
				}

				int var56;
				for(var25 = 0; var25 < 10; ++var25) {
					var26 = var50;
					var56 = 16;
					byte var57 = 0;
					if(this.mc.thePlayer.isPotionActive(Potion.hunger)) {
						var56 += 36;
						var57 = 13;
					}

					if(this.mc.thePlayer.getFoodStats().getFoodSaturationLevel() <= 0.0F && this.updateCounter % (var16 * 3 + 1) == 0) {
						var26 = var50 + (this.rand.nextInt(3) - 1);
					}

					if(var14) {
						var57 = 1;
					}

					var29 = var19 - var25 * 8 - 9;
					this.drawTexturedModalRect(var29, var26, 16 + var57 * 9, 27, 9, 9);
					if(var14) {
						if(var25 * 2 + 1 < var17) {
							this.drawTexturedModalRect(var29, var26, var56 + 54, 27, 9, 9);
						}

						if(var25 * 2 + 1 == var17) {
							this.drawTexturedModalRect(var29, var26, var56 + 63, 27, 9, 9);
						}
					}

					if(var25 * 2 + 1 < var16) {
						this.drawTexturedModalRect(var29, var26, var56 + 36, 27, 9, 9);
					}

					if(var25 * 2 + 1 == var16) {
						this.drawTexturedModalRect(var29, var26, var56 + 45, 27, 9, 9);
					}
				}

				if(this.mc.thePlayer.isInsideOfMaterial(Material.water)) {
					var25 = (int)Math.ceil((float)(this.mc.thePlayer.getAir() - 2) * 10.0D / 300.0D);
					var26 = (int)Math.ceil((float)this.mc.thePlayer.getAir() * 10.0D / 300.0D) - var25;

					for(var56 = 0; var56 < var25 + var26; ++var56) {
						if(var56 < var25) {
							this.drawTexturedModalRect(var19 - var56 * 8 - 9, var22, 16, 18, 9, 9);
						} else {
							this.drawTexturedModalRect(var19 - var56 * 8 - 9, var22, 25, 18, 9, 9);
						}
					}
				}
			}

			GL11.glDisable(GL11.GL_BLEND);
			GL11.glEnable('\u803a');
			RenderHelper.func_41089_c();

			for(var18 = 0; var18 < 9; ++var18) {
				var19 = var6 / 2 - 90 + var18 * 20 + 2;
				var20 = var7 - 16 - 3;
				this.renderInventorySlot(var18, var19, var20, var1);
			}

			RenderHelper.disableStandardItemLighting();
			GL11.glDisable('\u803a');
		}

		if(this.mc.thePlayer.getSleepTimer() > 0) {
			GL11.glDisable(GL11.GL_DEPTH_TEST);
			GL11.glDisable(GL11.GL_ALPHA_TEST);
			int var32 = this.mc.thePlayer.getSleepTimer();
			float var35 = (float)var32 / 100.0F;
			if(var35 > 1.0F) {
				var35 = 1.0F - (float)(var32 - 100) / 10.0F;
			}

			var12 = (int)(220.0F * var35) << 24 | 1052704;
			this.drawRect(0, 0, var6, var7, var12);
			GL11.glEnable(GL11.GL_ALPHA_TEST);
			GL11.glEnable(GL11.GL_DEPTH_TEST);
		}

		int var38;
		int var41;
		if(this.mc.playerController.func_35642_f() && this.mc.thePlayer.playerLevel > 0) {
			boolean var33 = false;
			var38 = var33 ? 16777215 : 8453920;
			String var37 = "" + this.mc.thePlayer.playerLevel;
			var13 = (var6 - var8.getStringWidth(var37)) / 2;
			var41 = var7 - 31 - 4;
			var8.drawString(var37, var13 + 1, var41, 0);
			var8.drawString(var37, var13 - 1, var41, 0);
			var8.drawString(var37, var13, var41 + 1, 0);
			var8.drawString(var37, var13, var41 - 1, 0);
			var8.drawString(var37, var13, var41, var38);
		}

		String var48;
		if(this.mc.gameSettings.showDebugInfo) {
			GL11.glPushMatrix();
			if(Minecraft.hasPaidCheckTime > 0L) {
				GL11.glTranslatef(0.0F, 32.0F, 0.0F);
			}

			var8.drawStringWithShadow("Minecraft Bedrock Edition (" + this.mc.debug + ")", 2, 2, 16777215);
			var8.drawStringWithShadow(this.mc.debugInfoRenders(), 2, 12, 16777215);
			var8.drawStringWithShadow(this.mc.func_6262_n(), 2, 22, 16777215);
			var8.drawStringWithShadow(this.mc.debugInfoEntities(), 2, 32, 16777215);
			var8.drawStringWithShadow(this.mc.func_21002_o(), 2, 42, 16777215);
			long var34 = Runtime.getRuntime().maxMemory();
			long var39 = Runtime.getRuntime().totalMemory();
			long var42 = Runtime.getRuntime().freeMemory();
			long var45 = var39 - var42;
			var48 = "Used memory: " + var45 * 100L / var34 + "% (" + var45 / 1024L / 1024L + "MB) of " + var34 / 1024L / 1024L + "MB";
			this.drawString(var8, var48, var6 - var8.getStringWidth(var48) - 2, 2, 14737632);
			var48 = "Allocated memory: " + var39 * 100L / var34 + "% (" + var39 / 1024L / 1024L + "MB)";
			this.drawString(var8, var48, var6 - var8.getStringWidth(var48) - 2, 12, 14737632);
			this.drawString(var8, "x: " + this.mc.thePlayer.posX, 2, 64, 14737632);
			this.drawString(var8, "y: " + this.mc.thePlayer.posY, 2, 72, 14737632);
			this.drawString(var8, "z: " + this.mc.thePlayer.posZ, 2, 80, 14737632);
			this.drawString(var8, "f: " + (MathHelper.floor_double((float)(this.mc.thePlayer.rotationYaw * 4.0F / 360.0F) + 0.5D) & 3), 2, 88, 14737632);
			this.drawString(var8, "Seed: " + this.mc.theWorld.getWorldSeed(), 2, 104, 14737632);
			GL11.glPopMatrix();
		}

		if(this.recordPlayingUpFor > 0) {
			var10 = (float)this.recordPlayingUpFor - var1;
			var38 = (int)(var10 * 256.0F / 20.0F);
			if(var38 > 255) {
				var38 = 255;
			}

			if(var38 > 0) {
				GL11.glPushMatrix();
				GL11.glTranslatef((float)(var6 / 2), (float)(var7 - 48), 0.0F);
				GL11.glEnable(GL11.GL_BLEND);
				GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
				var12 = 16777215;
				if(this.recordIsPlaying) {
					var12 = Color.HSBtoRGB(var10 / 50.0F, 0.7F, 0.6F) & 16777215;
				}

				var8.drawString(this.recordPlaying, -var8.getStringWidth(this.recordPlaying) / 2, -4, var12 + (var38 << 24));
				GL11.glDisable(GL11.GL_BLEND);
				GL11.glPopMatrix();
			}
		}

		byte var36 = 10;
		var11 = false;
		if(this.mc.currentScreen instanceof GuiChat) {
			var36 = 20;
			var11 = true;
		}

		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		GL11.glDisable(GL11.GL_ALPHA_TEST);
		GL11.glPushMatrix();
		GL11.glTranslatef(0.0F, (float)(var7 - 48), 0.0F);

		int var44;
		for(var12 = 0; var12 < this.chatMessageList.size() && var12 < var36; ++var12) {
			if(((ChatLine)this.chatMessageList.get(var12)).updateCounter < 200 || var11) {
				double var40 = (float)((ChatLine)this.chatMessageList.get(var12)).updateCounter / 200.0D;
				var40 = 1.0D - var40;
				var40 *= 10.0D;
				if(var40 < 0.0D) {
					var40 = 0.0D;
				}

				if(var40 > 1.0D) {
					var40 = 1.0D;
				}

				var40 *= var40;
				var44 = (int)(255.0D * var40);
				if(var11) {
					var44 = 255;
				}

				if(var44 > 0) {
					byte var47 = 2;
					var17 = -var12 * 9;
					var48 = ((ChatLine)this.chatMessageList.get(var12)).message;
					this.drawRect(var47, var17 - 1, var47 + 320, var17 + 8, var44 / 2 << 24);
					GL11.glEnable(GL11.GL_BLEND);
					var8.drawStringWithShadow(var48, var47, var17, 16777215 + (var44 << 24));
				}
			}
		}

		GL11.glPopMatrix();
		if(this.mc.thePlayer instanceof EntityClientPlayerMP && this.mc.gameSettings.keyBindPlayerList.pressed) {
			NetClientHandler var43 = ((EntityClientPlayerMP)this.mc.thePlayer).sendQueue;
			List var46 = var43.playerNames;
			var41 = var43.currentServerMaxPlayers;
			var44 = var41;

			for(var16 = 1; var44 > 20; var44 = (var41 + var16 - 1) / var16) {
				++var16;
			}

			var17 = 300 / var16;
			if(var17 > 150) {
				var17 = 150;
			}

			var18 = (var6 - var16 * var17) / 2;
			byte var49 = 10;
			this.drawRect(var18 - 1, var49 - 1, var18 + var17 * var16, var49 + 9 * var44, Integer.MIN_VALUE);

			for(var20 = 0; var20 < var41; ++var20) {
				var50 = var18 + var20 % var16 * var17;
				var22 = var49 + var20 / var16 * 9;
				this.drawRect(var50, var22, var50 + var17 - 1, var22 + 8, 553648127);
				GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
				GL11.glEnable(GL11.GL_ALPHA_TEST);
				if(var20 < var46.size()) {
					GuiSavingLevelString var51 = (GuiSavingLevelString)var46.get(var20);
					var8.drawStringWithShadow(var51.name, var50, var22, 16777215);
					this.mc.renderEngine.bindTexture(this.mc.renderEngine.getTexture("/gui/icons.png"));
					boolean var52 = false;
					boolean var54 = false;
					byte var53 = 0;
					var54 = false;
					byte var55;
					if(var51.responseTime < 0) {
						var55 = 5;
					} else if(var51.responseTime < 150) {
						var55 = 0;
					} else if(var51.responseTime < 300) {
						var55 = 1;
					} else if(var51.responseTime < 600) {
						var55 = 2;
					} else if(var51.responseTime < 1000) {
						var55 = 3;
					} else {
						var55 = 4;
					}

					this.zLevel += 100.0F;
					this.drawTexturedModalRect(var50 + var17 - 12, var22, 0 + var53 * 10, 176 + var55 * 8, 10, 8);
					this.zLevel -= 100.0F;
				}
			}
		}

		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		GL11.glDisable(GL11.GL_LIGHTING);
		GL11.glEnable(GL11.GL_ALPHA_TEST);
	}

	private void renderBossHealth() {
		if(RenderDragon.entityDragon != null) {
			EntityDragon var1 = RenderDragon.entityDragon;
			RenderDragon.entityDragon = null;
			FontRenderer var2 = this.mc.fontRenderer;
			ScaledResolution var3 = new ScaledResolution(this.mc.gameSettings, this.mc.displayWidth, this.mc.displayHeight);
			int var4 = var3.getScaledWidth();
			short var5 = 182;
			int var6 = var4 / 2 - var5 / 2;
			int var7 = (int)((float)var1.func_41010_ax() / (float)var1.getMaxHealth() * (float)(var5 + 1));
			byte var8 = 12;
			this.drawTexturedModalRect(var6, var8, 0, 74, var5, 5);
			this.drawTexturedModalRect(var6, var8, 0, 74, var5, 5);
			if(var7 > 0) {
				this.drawTexturedModalRect(var6, var8, 0, 79, var7, 5);
			}

			String var9 = "Boss health";
			var2.drawStringWithShadow(var9, var4 / 2 - var2.getStringWidth(var9) / 2, var8 - 10, 16711935);
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
			GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.mc.renderEngine.getTexture("/gui/icons.png"));
		}
	}

	private void renderPumpkinBlur(int var1, int var2) {
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GL11.glDepthMask(false);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		GL11.glDisable(GL11.GL_ALPHA_TEST);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.mc.renderEngine.getTexture("%blur%/misc/pumpkinblur.png"));
		Tessellator var3 = Tessellator.instance;
		var3.startDrawingQuads();
		var3.addVertexWithUV(0.0D, (float)var2, -90.0D, 0.0D, 1.0D);
		var3.addVertexWithUV((float)var1, (float)var2, -90.0D, 1.0D, 1.0D);
		var3.addVertexWithUV((float)var1, 0.0D, -90.0D, 1.0D, 0.0D);
		var3.addVertexWithUV(0.0D, 0.0D, -90.0D, 0.0D, 0.0D);
		var3.draw();
		GL11.glDepthMask(true);
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glEnable(GL11.GL_ALPHA_TEST);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
	}

	private void renderVignette(float var1, int var2, int var3) {
		var1 = 1.0F - var1;
		if(var1 < 0.0F) {
			var1 = 0.0F;
		}

		if(var1 > 1.0F) {
			var1 = 1.0F;
		}

		this.prevVignetteBrightness = (float)((float)this.prevVignetteBrightness + (float)(var1 - this.prevVignetteBrightness) * 0.01D);
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GL11.glDepthMask(false);
		GL11.glBlendFunc(GL11.GL_ZERO, GL11.GL_ONE_MINUS_SRC_COLOR);
		GL11.glColor4f(this.prevVignetteBrightness, this.prevVignetteBrightness, this.prevVignetteBrightness, 1.0F);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.mc.renderEngine.getTexture("%blur%/misc/vignette.png"));
		Tessellator var4 = Tessellator.instance;
		var4.startDrawingQuads();
		var4.addVertexWithUV(0.0D, (float)var3, -90.0D, 0.0D, 1.0D);
		var4.addVertexWithUV((float)var2, (float)var3, -90.0D, 1.0D, 1.0D);
		var4.addVertexWithUV((float)var2, 0.0D, -90.0D, 1.0D, 0.0D);
		var4.addVertexWithUV(0.0D, 0.0D, -90.0D, 0.0D, 0.0D);
		var4.draw();
		GL11.glDepthMask(true);
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
	}

	private void renderPortalOverlay(float var1, int var2, int var3) {
		if(var1 < 1.0F) {
			var1 *= var1;
			var1 *= var1;
			var1 = var1 * 0.8F + 0.2F;
		}

		GL11.glDisable(GL11.GL_ALPHA_TEST);
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GL11.glDepthMask(false);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, var1);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.mc.renderEngine.getTexture("/terrain.png"));
		float var4 = (float)(Block.portal.blockIndexInTexture % 16) / 16.0F;
		float var5 = (float)(Block.portal.blockIndexInTexture / 16) / 16.0F;
		float var6 = (float)(Block.portal.blockIndexInTexture % 16 + 1) / 16.0F;
		float var7 = (float)(Block.portal.blockIndexInTexture / 16 + 1) / 16.0F;
		Tessellator var8 = Tessellator.instance;
		var8.startDrawingQuads();
		var8.addVertexWithUV(0.0D, (float)var3, -90.0D, (float)var4, (float)var7);
		var8.addVertexWithUV((float)var2, (float)var3, -90.0D, (float)var6, (float)var7);
		var8.addVertexWithUV((float)var2, 0.0D, -90.0D, (float)var6, (float)var5);
		var8.addVertexWithUV(0.0D, 0.0D, -90.0D, (float)var4, (float)var5);
		var8.draw();
		GL11.glDepthMask(true);
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glEnable(GL11.GL_ALPHA_TEST);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
	}

	private void renderInventorySlot(int var1, int var2, int var3, float var4) {
		ItemStack var5 = this.mc.thePlayer.inventory.mainInventory[var1];
		if(var5 != null) {
			float var6 = (float)var5.animationsToGo - var4;
			if(var6 > 0.0F) {
				GL11.glPushMatrix();
				float var7 = 1.0F + var6 / 5.0F;
				GL11.glTranslatef((float)(var2 + 8), (float)(var3 + 12), 0.0F);
				GL11.glScalef(1.0F / var7, (var7 + 1.0F) / 2.0F, 1.0F);
				GL11.glTranslatef((float)(-(var2 + 8)), (float)(-(var3 + 12)), 0.0F);
			}

			itemRenderer.renderItemIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, var5, var2, var3);
			if(var6 > 0.0F) {
				GL11.glPopMatrix();
			}

			itemRenderer.renderItemOverlayIntoGUI(this.mc.fontRenderer, this.mc.renderEngine, var5, var2, var3);
		}
	}

	public void updateTick() {
		if(this.recordPlayingUpFor > 0) {
			--this.recordPlayingUpFor;
		}

		++this.updateCounter;

		for(int var1 = 0; var1 < this.chatMessageList.size(); ++var1) {
			++((ChatLine)this.chatMessageList.get(var1)).updateCounter;
		}

	}

	public void clearChatMessages() {
		this.chatMessageList.clear();
	}

	public void addChatMessage(String var1) {
		while(this.mc.fontRenderer.getStringWidth(var1) > 320) {
			int var2;
			for(var2 = 1; var2 < var1.length() && this.mc.fontRenderer.getStringWidth(var1.substring(0, var2 + 1)) <= 320; ++var2) {
				;
			}

			this.addChatMessage(var1.substring(0, var2));
			var1 = var1.substring(var2);
		}

		this.chatMessageList.add(0, new ChatLine(var1));

		while(this.chatMessageList.size() > 50) {
			this.chatMessageList.remove(this.chatMessageList.size() - 1);
		}

	}

	public void setRecordPlayingMessage(String var1) {
		this.recordPlaying = "Now playing: " + var1;
		this.recordPlayingUpFor = 60;
		this.recordIsPlaying = true;
	}

	public void addChatMessageTranslate(String var1) {
		StringTranslate var2 = StringTranslate.getInstance();
		String var3 = var2.translateKey(var1);
		this.addChatMessage(var3);
	}
}

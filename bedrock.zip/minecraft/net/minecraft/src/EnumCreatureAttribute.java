package net.minecraft.src;

public enum EnumCreatureAttribute {
	UNDEFINED,
	UNDEAD,
	ARTHROPOD;
}

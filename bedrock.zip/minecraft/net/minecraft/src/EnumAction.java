package net.minecraft.src;

public enum EnumAction {
	none,
	eat,
	drink,
	block,
	bow;
}

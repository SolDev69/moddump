package net.minecraft.src;

public class EntityEggInfo {
	public int field_46063_a;
	public int field_46061_b;
	public int field_46062_c;

	public EntityEggInfo(int var1, int var2, int var3) {
		this.field_46063_a = var1;
		this.field_46061_b = var2;
		this.field_46062_c = var3;
	}
}

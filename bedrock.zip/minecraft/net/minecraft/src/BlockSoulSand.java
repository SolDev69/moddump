package net.minecraft.src;

public class BlockSoulSand extends Block {
	public BlockSoulSand(int var1, int var2) {
		super(var1, var2, Material.sand);
	}

	public AxisAlignedBB getCollisionBoundingBoxFromPool(World var1, int var2, int var3, int var4) {
		float var5 = 0.125F;
		return AxisAlignedBB.getBoundingBoxFromPool((float)var2, (float)var3, (float)var4, (float)(var2 + 1), (float)((float)(var3 + 1) - var5), (float)(var4 + 1));
	}

	public void onEntityCollidedWithBlock(World var1, int var2, int var3, int var4, Entity var5) {
		var5.motionX *= 0.4D;
		var5.motionZ *= 0.4D;
	}
}

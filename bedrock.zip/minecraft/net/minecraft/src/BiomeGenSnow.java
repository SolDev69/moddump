package net.minecraft.src;

public class BiomeGenSnow extends BiomeGenBase {
	public BiomeGenSnow(int var1) {
		super(var1);
	}
}

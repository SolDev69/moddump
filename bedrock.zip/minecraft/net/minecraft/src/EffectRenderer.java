package net.minecraft.src;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.lwjgl.opengl.GL11;

public class EffectRenderer {
	protected World worldObj;
	private List[] fxLayers = new List[4];
	private RenderEngine renderer;
	private Random rand = new Random();

	public EffectRenderer(World var1, RenderEngine var2) {
		if(var1 != null) {
			this.worldObj = var1;
		}

		this.renderer = var2;

		for(int var3 = 0; var3 < 4; ++var3) {
			this.fxLayers[var3] = new ArrayList();
		}

	}

	public void addEffect(EntityFX var1) {
		int var2 = var1.getFXLayer();
		if(this.fxLayers[var2].size() >= 4000) {
			this.fxLayers[var2].remove(0);
		}

		this.fxLayers[var2].add(var1);
	}

	public void updateEffects() {
		for(int var1 = 0; var1 < 4; ++var1) {
			for(int var2 = 0; var2 < this.fxLayers[var1].size(); ++var2) {
				EntityFX var3 = (EntityFX)this.fxLayers[var1].get(var2);
				var3.onUpdate();
				if(var3.isDead) {
					this.fxLayers[var1].remove(var2--);
				}
			}
		}

	}

	public void renderParticles(Entity var1, float var2) {
		float var3 = ActiveRenderInfo.rotationX;
		float var4 = ActiveRenderInfo.rotationZ;
		float var5 = ActiveRenderInfo.rotationYZ;
		float var6 = ActiveRenderInfo.rotationXY;
		float var7 = ActiveRenderInfo.rotationXZ;
		EntityFX.interpPosX = var1.lastTickPosX + (var1.posX - var1.lastTickPosX) * (float)var2;
		EntityFX.interpPosY = var1.lastTickPosY + (var1.posY - var1.lastTickPosY) * (float)var2;
		EntityFX.interpPosZ = var1.lastTickPosZ + (var1.posZ - var1.lastTickPosZ) * (float)var2;

		for(int var8 = 0; var8 < 3; ++var8) {
			if(this.fxLayers[var8].size() != 0) {
				int var9 = 0;
				if(var8 == 0) {
					var9 = this.renderer.getTexture("/particles.png");
				}

				if(var8 == 1) {
					var9 = this.renderer.getTexture("/terrain.png");
				}

				if(var8 == 2) {
					var9 = this.renderer.getTexture("/gui/items.png");
				}

				GL11.glBindTexture(GL11.GL_TEXTURE_2D, var9);
				Tessellator var10 = Tessellator.instance;
				GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
				var10.startDrawingQuads();

				for(int var11 = 0; var11 < this.fxLayers[var8].size(); ++var11) {
					EntityFX var12 = (EntityFX)this.fxLayers[var8].get(var11);
					var10.setBrightness(var12.getEntityBrightnessForRender(var2));
					var12.renderParticle(var10, var2, var3, var7, var4, var5, var6);
				}

				var10.draw();
			}
		}

	}

	public void func_1187_b(Entity var1, float var2) {
		float var3 = MathHelper.cos(var1.rotationYaw * 3.1415927F / 180.0F);
		float var4 = MathHelper.sin(var1.rotationYaw * 3.1415927F / 180.0F);
		float var5 = -var4 * MathHelper.sin(var1.rotationPitch * 3.1415927F / 180.0F);
		float var6 = var3 * MathHelper.sin(var1.rotationPitch * 3.1415927F / 180.0F);
		float var7 = MathHelper.cos(var1.rotationPitch * 3.1415927F / 180.0F);
		byte var8 = 3;
		if(this.fxLayers[var8].size() != 0) {
			Tessellator var9 = Tessellator.instance;

			for(int var10 = 0; var10 < this.fxLayers[var8].size(); ++var10) {
				EntityFX var11 = (EntityFX)this.fxLayers[var8].get(var10);
				var9.setBrightness(var11.getEntityBrightnessForRender(var2));
				var11.renderParticle(var9, var2, var3, var7, var4, var5, var6);
			}

		}
	}

	public void clearEffects(World var1) {
		this.worldObj = var1;

		for(int var2 = 0; var2 < 4; ++var2) {
			this.fxLayers[var2].clear();
		}

	}

	public void addBlockDestroyEffects(int var1, int var2, int var3, int var4, int var5) {
		if(var4 != 0) {
			Block var6 = Block.blocksList[var4];
			byte var7 = 4;

			for(int var8 = 0; var8 < var7; ++var8) {
				for(int var9 = 0; var9 < var7; ++var9) {
					for(int var10 = 0; var10 < var7; ++var10) {
						double var11 = (float)var1 + ((float)var8 + 0.5D) / (float)var7;
						double var13 = (float)var2 + ((float)var9 + 0.5D) / (float)var7;
						double var15 = (float)var3 + ((float)var10 + 0.5D) / (float)var7;
						int var17 = this.rand.nextInt(6);
						this.addEffect((new EntityDiggingFX(this.worldObj, var11, var13, var15, var11 - (float)var1 - 0.5D, var13 - (float)var2 - 0.5D, var15 - (float)var3 - 0.5D, var6, var17, var5)).func_4041_a(var1, var2, var3));
					}
				}
			}

		}
	}

	public void addBlockHitEffects(int var1, int var2, int var3, int var4) {
		int var5 = this.worldObj.getBlockId(var1, var2, var3);
		if(var5 != 0) {
			Block var6 = Block.blocksList[var5];
			float var7 = 0.1F;
			double var8 = (float)var1 + this.rand.nextDouble() * (var6.maxX - var6.minX - (float)(var7 * 2.0F)) + (float)var7 + var6.minX;
			double var10 = (float)var2 + this.rand.nextDouble() * (var6.maxY - var6.minY - (float)(var7 * 2.0F)) + (float)var7 + var6.minY;
			double var12 = (float)var3 + this.rand.nextDouble() * (var6.maxZ - var6.minZ - (float)(var7 * 2.0F)) + (float)var7 + var6.minZ;
			if(var4 == 0) {
				var10 = (float)var2 + var6.minY - (float)var7;
			}

			if(var4 == 1) {
				var10 = (float)var2 + var6.maxY + (float)var7;
			}

			if(var4 == 2) {
				var12 = (float)var3 + var6.minZ - (float)var7;
			}

			if(var4 == 3) {
				var12 = (float)var3 + var6.maxZ + (float)var7;
			}

			if(var4 == 4) {
				var8 = (float)var1 + var6.minX - (float)var7;
			}

			if(var4 == 5) {
				var8 = (float)var1 + var6.maxX + (float)var7;
			}

			this.addEffect((new EntityDiggingFX(this.worldObj, var8, var10, var12, 0.0D, 0.0D, 0.0D, var6, var4, this.worldObj.getBlockMetadata(var1, var2, var3))).func_4041_a(var1, var2, var3).multiplyVelocity(0.2F).func_405_d(0.6F));
		}
	}

	public String getStatistics() {
		return "" + (this.fxLayers[0].size() + this.fxLayers[1].size() + this.fxLayers[2].size());
	}
}

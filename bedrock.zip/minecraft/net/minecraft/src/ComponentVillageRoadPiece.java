package net.minecraft.src;

public abstract class ComponentVillageRoadPiece extends ComponentVillage {
	protected ComponentVillageRoadPiece(int var1) {
		super(var1);
	}
}

package net.minecraft.src;

class EntityAITaskEntry {
	public EntityAIBase field_46114_a;
	public int field_46112_b;
	final EntityAITasks field_46113_c;

	public EntityAITaskEntry(EntityAITasks var1, int var2, EntityAIBase var3) {
		this.field_46113_c = var1;
		this.field_46112_b = var2;
		this.field_46114_a = var3;
	}
}

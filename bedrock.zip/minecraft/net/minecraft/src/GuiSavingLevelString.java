package net.minecraft.src;

public class GuiSavingLevelString {
	public String name;
	public int responseTime;

	public GuiSavingLevelString(String var1) {
		this.name = var1;
	}
}

package net.minecraft.src;

public interface INavigate {
	void func_46071_a(double var1, double var3, double var5, float var7);

	void func_46070_a(EntityLiving var1, float var2);

	void func_46069_a();

	boolean func_46072_b();
}

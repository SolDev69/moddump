package net.minecraft.src;

public interface IStatStringFormat {
	String formatString(String var1);
}

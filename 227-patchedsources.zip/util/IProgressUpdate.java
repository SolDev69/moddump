package util;

public interface IProgressUpdate {
	void displayProgressMessage(String var1);

	void displayLoadingString(String var1);
}

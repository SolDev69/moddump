package com.mojang.nbt;

public abstract class NBTBase {
}

package net.minecraft.game.item;

import net.minecraft.game.world.block.Block;

public final class ItemAxe extends ItemTool {
	private static Block[] blocksEffectiveAgainst;

	public ItemAxe(int var1, int var2) {
		super(var1, 3, var2, blocksEffectiveAgainst);
	}

	static {
		blocksEffectiveAgainst = new Block[]{Block.planks, Block.bookShelf, Block.wood, Block.waterSource};
	}
}

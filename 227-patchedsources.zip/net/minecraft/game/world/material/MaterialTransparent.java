package net.minecraft.game.world.material;

public final class MaterialTransparent extends Material {
	public final boolean isSolid() {
		return false;
	}

	public final boolean getCanBlockGrass() {
		return false;
	}
}

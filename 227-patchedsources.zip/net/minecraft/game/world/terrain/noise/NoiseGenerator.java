package net.minecraft.game.world.terrain.noise;

public abstract class NoiseGenerator {
}

package net.minecraft.game.world.terrain;

public final class LevelGenerator {
}

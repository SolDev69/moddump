package net.minecraft.game.world.block;

import net.minecraft.game.world.material.Material;

public abstract class BlockContainer extends Block {
	protected BlockContainer(int var1, Material var2) {
		super(var1, var2);
	}
}

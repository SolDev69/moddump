package net.minecraft.game.world.block;

public final class BlockSapling extends BlockFlower {
	protected BlockSapling(int var1, int var2) {
		super(6, 15);
		this.setBlockBounds(0.099999994F, 0.0F, 0.099999994F, 0.9F, 0.8F, 0.9F);
	}
}

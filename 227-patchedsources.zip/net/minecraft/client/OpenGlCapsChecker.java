package net.minecraft.client;

public final class OpenGlCapsChecker {
}

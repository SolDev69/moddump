package net.minecraft.client;

import net.minecraft.game.world.LevelLoader;
import util.IProgressUpdate;

public final class PlayerLoader extends LevelLoader {
	public PlayerLoader(Minecraft var1, IProgressUpdate var2) {
		super(var2);
	}
}

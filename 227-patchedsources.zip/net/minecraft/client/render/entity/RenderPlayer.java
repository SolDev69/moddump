package net.minecraft.client.render.entity;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.game.entity.Entity;
import net.minecraft.game.entity.EntityLiving;
import net.minecraft.game.entity.player.EntityPlayer;
import net.minecraft.game.entity.player.InventoryPlayer;
import net.minecraft.game.item.Item;
import net.minecraft.game.item.ItemArmor;
import net.minecraft.game.item.ItemStack;

public final class RenderPlayer extends RenderLiving {
	private ModelBiped modelBipedMain;
	private ModelBiped modelArmorChestplate;
	private ModelBiped modelArmor;
	private static final String[] armorFilenamePrefix = new String[]{"cloth", "chain", "iron", "diamond", "gold"};

	public RenderPlayer() {
		super(new ModelBiped(0.0F), 0.5F);
		this.modelBipedMain = (ModelBiped)this.mainModel;
		this.modelArmorChestplate = new ModelBiped(1.0F);
		this.modelArmor = new ModelBiped(0.5F);
	}

	private void renderPlayer(EntityPlayer var1, double var2, double var4, double var6, float var8, float var9) {
		super.a(var1, var2, var4 - (double)var1.yOffset, var6, var8, var9);
	}

	public final void drawFirstPersonHand() {
		this.modelBipedMain.bipedRightArm.render(1.0F);
	}

	protected final boolean shouldRenderPass(EntityLiving var1, int var2) {
		EntityPlayer var10001 = (EntityPlayer)var1;
		int var3 = var2;
		EntityPlayer var5 = var10001;
		int var4 = 3 - var3;
		InventoryPlayer var10 = var5.inventory;
		ItemStack var6;
		Item var7;
		if((var6 = var5.inventory.armorInventory[var4]) != null && (var7 = var6.getItem()) instanceof ItemArmor) {
			ItemArmor var8 = (ItemArmor)var7;
			this.loadTexture("/armor/" + armorFilenamePrefix[var8.renderIndex] + "_" + (var3 == 2 ? 2 : 1) + ".png");
			ModelBiped var9 = var3 == 2 ? this.modelArmor : this.modelArmorChestplate;
			var9.bipedHead.showModel = var3 == 0;
			var9.bipedHeadwear.showModel = var3 == 0;
			var9.bipedBody.showModel = var3 == 1 || var3 == 2;
			var9.bipedRightArm.showModel = var3 == 1;
			var9.bipedLeftArm.showModel = var3 == 1;
			var9.bipedRightLeg.showModel = var3 == 2 || var3 == 3;
			var9.bipedLeftLeg.showModel = var3 == 2 || var3 == 3;
			this.setRenderPassModel(var9);
			return true;
		} else {
			return false;
		}
	}

	public final void a(EntityLiving var1, double var2, double var4, double var6, float var8, float var9) {
		this.renderPlayer((EntityPlayer)var1, var2, var4, var6, var8, var9);
	}

	public final void doRender(Entity var1, double var2, double var4, double var6, float var8, float var9) {
		this.renderPlayer((EntityPlayer)var1, var2, var4, var6, var8, var9);
	}
}

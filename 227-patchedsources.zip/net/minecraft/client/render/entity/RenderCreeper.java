package net.minecraft.client.render.entity;

import net.minecraft.client.model.ModelCreeper;
import net.minecraft.game.entity.EntityLiving;
import net.minecraft.game.entity.monster.EntityCreeper;
import org.lwjgl.opengl.GL11;
import util.MathHelper;

public final class RenderCreeper extends RenderLiving {
	public RenderCreeper() {
		super(new ModelCreeper(), 0.5F);
	}

	protected final void preRenderCallback(EntityLiving var1, float var2) {
		float var4 = ((EntityCreeper)var1).c(var2);
		var2 = 1.0F + MathHelper.sin(var4 * 100.0F) * var4 * 0.01F;
		if(var4 < 0.0F) {
			var4 = 0.0F;
		}

		if(var4 > 1.0F) {
			var4 = 1.0F;
		}

		var4 = (var4 *= var4) * var4;
		float var3 = (1.0F + var4 * 0.4F) * var2;
		var4 = (1.0F + var4 * 0.1F) / var2;
		GL11.glScalef(var3, var4, var3);
	}

	protected final int getColorMultiplier(EntityLiving var1, float var2, float var3) {
		float var4;
		if((int)((var4 = ((EntityCreeper)var1).c(var3)) * 10.0F) % 2 == 0) {
			return 0;
		} else {
			int var5;
			if((var5 = (int)(var4 * 0.2F * 255.0F)) < 0) {
				var5 = 0;
			}

			if(var5 > 255) {
				var5 = 255;
			}

			return var5 << 24 | 16711680 | '\uff00' | 255;
		}
	}
}

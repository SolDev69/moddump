package net.minecraft.client.render.camera;

import net.minecraft.game.physics.AxisAlignedBB;

public class Frustrum {
	private ClippingHelper clippingHelper = ClippingHelperImplementation.init();

	public boolean isBoundingBoxInFrustrum(AxisAlignedBB var1) {
		ClippingHelper var10001 = this.clippingHelper;
		double var15 = var1.maxZ;
		double var13 = var1.maxY;
		double var11 = var1.maxX;
		double var9 = var1.minZ;
		double var7 = var1.minY;
		double var5 = var1.minX;
		ClippingHelper var17 = this.clippingHelper;

		for(int var2 = 0; var2 < 6; ++var2) {
			if((double)var17.frustrum[var2][0] * var5 + (double)var17.frustrum[var2][1] * var7 + (double)var17.frustrum[var2][2] * var9 + (double)var17.frustrum[var2][3] <= 0.0D && (double)var17.frustrum[var2][0] * var11 + (double)var17.frustrum[var2][1] * var7 + (double)var17.frustrum[var2][2] * var9 + (double)var17.frustrum[var2][3] <= 0.0D && (double)var17.frustrum[var2][0] * var5 + (double)var17.frustrum[var2][1] * var13 + (double)var17.frustrum[var2][2] * var9 + (double)var17.frustrum[var2][3] <= 0.0D && (double)var17.frustrum[var2][0] * var11 + (double)var17.frustrum[var2][1] * var13 + (double)var17.frustrum[var2][2] * var9 + (double)var17.frustrum[var2][3] <= 0.0D && (double)var17.frustrum[var2][0] * var5 + (double)var17.frustrum[var2][1] * var7 + (double)var17.frustrum[var2][2] * var15 + (double)var17.frustrum[var2][3] <= 0.0D && (double)var17.frustrum[var2][0] * var11 + (double)var17.frustrum[var2][1] * var7 + (double)var17.frustrum[var2][2] * var15 + (double)var17.frustrum[var2][3] <= 0.0D && (double)var17.frustrum[var2][0] * var5 + (double)var17.frustrum[var2][1] * var13 + (double)var17.frustrum[var2][2] * var15 + (double)var17.frustrum[var2][3] <= 0.0D && (double)var17.frustrum[var2][0] * var11 + (double)var17.frustrum[var2][1] * var13 + (double)var17.frustrum[var2][2] * var15 + (double)var17.frustrum[var2][3] <= 0.0D) {
				return false;
			}
		}

		return true;
	}
}

package net.minecraft.client.render;

public class ThreadDownloadImageData {
	public int chunksUpdated;
	public boolean textureSetupComplete;
	public int updateCounter;
}
